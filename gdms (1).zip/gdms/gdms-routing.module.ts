import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GdmsBaseComponent } from './gdms-base/gdms-base.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminPoliciesListComponent } from './dm-admin/dm-admin-list/dm-admin-policies-list/dm-admin-policies-list.component';
import { AdminProceduresListComponent } from './dm-admin/dm-admin-list/dm-admin-procedures-list/dm-admin-procedures-list.component';
import { AdminFormatsListComponent } from './dm-admin/dm-admin-list/dm-admin-formats-list/dm-admin-formats-list.component';
import { SitePoliciesListComponent } from './dm-site/dm-site-list/dm-site-policies-list/dm-site-policies-list.component';
import { SiteFormatsListComponent } from './dm-site/dm-site-list/dm-site-formats-list/dm-site-formats-list.component';
import { SiteProceduresListComponent } from './dm-site/dm-site-list/dm-site-procedures-list/dm-site-procedures-list.component';
import { ProceduresComponent } from './procedures/procedures.component';
import { DmPolicyDetailsComponent } from './dm-admin/dm-admin-create/dm-policy-details/dm-policy-details.component';
import { DmProcedureDetailsComponent } from './dm-admin/dm-admin-create/dm-procedure-details/dm-procedure-details.component';
import { DmFormatDetailsComponent } from './dm-admin/dm-admin-create/dm-format-details/dm-format-details.component';
import { PoliciesComponent } from './policies/policies.component';
import { FormatsComponent } from './formats/formats.component';

const gdmsRoutes: Routes = [
  {
    path: "", component: GdmsBaseComponent,
    children: [
      { path: "dashboard", component: DashboardComponent },
      { path: "admin/policies/drafts/list", component: AdminPoliciesListComponent },
      { path: "admin/policies/pendings/list", component: AdminPoliciesListComponent },
      { path: "admin/policies/reviews/list", component: AdminPoliciesListComponent },
      { path: "admin/policies/published/list", component: AdminPoliciesListComponent },
      { path: "admin/procedures/drafts/list", component: AdminProceduresListComponent },
      { path: "admin/procedures/pendings/list", component: AdminProceduresListComponent },
      { path: "admin/procedures/reviews/list", component: AdminProceduresListComponent },
      { path: "admin/procedures/published/list", component: AdminProceduresListComponent },
      { path: "admin/formats/drafts/list", component: AdminFormatsListComponent },
      { path: "admin/formats/pendings/list", component: AdminFormatsListComponent },
      { path: "admin/formats/reviews/list", component: AdminFormatsListComponent },
      { path: "admin/formats/published/list", component: AdminFormatsListComponent },
      { path: "site/policies/drafts/list", component: SitePoliciesListComponent },
      { path: "site/policies/pendings/list", component: SitePoliciesListComponent },
      { path: "site/policies/reviews/list", component: SitePoliciesListComponent },
      { path: "site/policies/published/list", component: SitePoliciesListComponent },
      { path: "site/procedures/drafts/list", component: SiteProceduresListComponent },
      { path: "site/procedures/pendings/list", component: SiteProceduresListComponent },
      { path: "site/procedures/reviews/list", component: SiteProceduresListComponent },
      { path: "site/procedures/published/list", component: SiteProceduresListComponent },
      { path: "site/formats/drafts/list", component: SiteFormatsListComponent },
      { path: "site/formats/pendings/list", component: SiteFormatsListComponent },
      { path: "site/formats/reviews/list", component: SiteFormatsListComponent },
      { path: "site/formats/published/list", component: SiteFormatsListComponent },
      { path: "policies", component: PoliciesComponent },
      { path: "formats", component: FormatsComponent },
      { path: "procedures", component: ProceduresComponent },
      { path: "admin/policies/:id/:id", component: DmPolicyDetailsComponent },
      { path: "admin/procedures/:id/:id", component: DmProcedureDetailsComponent },
      { path: "admin/formats/:id/:id", component: DmFormatDetailsComponent },
      { path: "site/policies/:id/:id", component: DmPolicyDetailsComponent },
      { path: "site/procedures/:id/:id", component: DmProcedureDetailsComponent },
      { path: "site/formats/:id/:id", component: DmFormatDetailsComponent },
      { path: "procedures/:key/:id/:id", component: DmProcedureDetailsComponent },
      { path: "policies/:key/:id/:id", component: DmPolicyDetailsComponent },
      { path: "formats/:key/:id/:id", component: DmFormatDetailsComponent },
      { path: '**', redirectTo: 'dashboard' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(gdmsRoutes)],
  exports: [RouterModule]
})
export class GdmsRoutingModule { }
