import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminProceduresListComponent } from './dm-admin-procedures-list.component';

describe('ProcessListComponent', () => {
  let component: AdminProceduresListComponent;
  let fixture: ComponentFixture<AdminProceduresListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminProceduresListComponent]
    });
    fixture = TestBed.createComponent(AdminProceduresListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
