import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPoliciesListComponent } from './dm-admin-policies-list.component';

describe('ProcessListComponent', () => {
  let component: AdminPoliciesListComponent;
  let fixture: ComponentFixture<AdminPoliciesListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminPoliciesListComponent]
    });
    fixture = TestBed.createComponent(AdminPoliciesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
