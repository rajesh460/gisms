import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminFormatsListComponent } from './dm-admin-formats-list.component';

describe('ProcessListComponent', () => {
  let component: AdminFormatsListComponent;
  let fixture: ComponentFixture<AdminFormatsListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminFormatsListComponent]
    });
    fixture = TestBed.createComponent(AdminFormatsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
