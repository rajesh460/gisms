import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DmPolicyDetailsComponent } from './dm-policy-details.component';

describe('DmPolicyDetailsComponent', () => {
  let component: DmPolicyDetailsComponent;
  let fixture: ComponentFixture<DmPolicyDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DmPolicyDetailsComponent]
    });
    fixture = TestBed.createComponent(DmPolicyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
