import { Component, ViewChild, OnInit, ChangeDetectorRef, ElementRef, Renderer2, OnDestroy } from '@angular/core';
import { FormArray, FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GdmsService } from '../../../gdms-services/gdms.service';
import { CommonUtilityService } from 'src/app/services/common-utility.service';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ConfirmationService, MessageService, ConfirmEventType } from 'primeng/api';
import { SafeResourceUrl, DomSanitizer } from "@angular/platform-browser";
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { NgForm } from '@angular/forms';
import { Dialog } from 'primeng/dialog';


@Component({
  selector: 'app-dm-policy-details',
  templateUrl: './dm-policy-details.component.html',
  styleUrls: ['./dm-policy-details.component.scss']
})
export class DmPolicyDetailsComponent implements OnInit {

  files: any = [];
  checked: boolean = false;
  activeFormats: any = [];
  submitted: boolean = false;
  @ViewChild('content') elementView: ElementRef;
  contentHeight: number;
  policyDocId: any;
  createForm: FormGroup;
  loading: boolean = false;
  histLoading: boolean = false;
  locationTypes: any = [];
  sbus: any = [];
  departments: any = [];
  allRoles: any = [];
  subKey: any;
  navData: any = [];
  validateAll: boolean = false;
  disableSubmitBtn: boolean = true;
  approveVisible: boolean = false;
  policyDetails: any = {};
  actions: any = [
    { name: 'Approve', key: 'APPROVE' },
    { name: 'Reject', key: 'REJECT' },
  ];
  minDate: any = new Date();
  parentPathName: any;
  historyFlag: boolean = false;
  urlSafe: SafeResourceUrl;
  classificationTypes: any = [];
  proCategories: any = [];
  subType: any;
  approvalsHistory: any = [];
  preHeader: any;
  visiblePdf: boolean = false;
  preImageUrl;
  allPolicysList: any;



  constructor (private fb: FormBuilder,
    private route: ActivatedRoute,
    private gdmsService: GdmsService,
    private commonUtilityService: CommonUtilityService,
    private cd: ChangeDetectorRef,
    private router: Router,
    private httpClient: HttpClient,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private sanitizer: DomSanitizer, private renderer: Renderer2) {
    this.getMasterData('DM_POLI_CATEGORY');
    this.getMasterData('DM_CLASSIFICATION');
  }


  onResize(ev) {
    this.contentHeight = ev.contentRect.height + 67.75;
    // if (ev.contentRect.width < 500) {
    //   this.renderer.setStyle(ev.target, 'background', 'red');
    // } else {
    //   this.renderer.removeStyle(ev.target, 'background');
    // }
  }


  ngOnInit(): void {
    let subKeyList = [{ name: 'drafts', value: 'DRAFTS' }, { name: 'pendings', value: 'PENDING_WITH_ME' }, { name: 'reviews', value: 'PENDING_IN_REVIEW' }, { name: 'published', value: 'PUBLISHED' }];
    let parentPathList = [{ name: 'admin', value: 'ADMIN' }, { name: 'site', value: 'SITE' }];
    let currentPathList = this.router.url.split('/');
    this.allPolicysList = currentPathList.includes('all');
    this.subKey = subKeyList.filter(value => currentPathList.includes(value.name))[0];
    let subTypesList = [{ name: 'policies', value: 'POLICIES' }, { name: 'procedures', value: 'PROCEDURES' }, { name: 'formats', value: 'FORMATS' }];
    this.subType = subTypesList.filter(value => currentPathList.includes(value.name))[0];
    this.parentPathName = parentPathList.filter(value => currentPathList.includes(value.name))[0];
    this.historyFlag = currentPathList.includes('history');
    this.policyDocId = this.route.snapshot.paramMap.get('id');
    if (this.policyDocId) {
      // this.getMasterData('LOCATION_TYPE');
      // this.getMasterData('SBU');
      this.getCreateForm();
      setTimeout(() => {
        this.getPolicyBydocId();
      }, 300);
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl('');
    }
  }

  getCreateForm() {
    this.createForm = this.fb.group({
      title: ['', Validators.required],
      classification: ['', Validators.required],
      category: ['', Validators.required],
      desc: ['', Validators.required],
      attachments: ['', Validators.required],
      action: [''],
      remarks: [''],
      reviewDate: [''],
      notes: ['', this.policyDetails && (this.policyDetails.originType === 'ISSUE' || this.policyDetails.originType === 'REVISION') ? Validators.required : []],
    });
  }

  get f() {
    return this.createForm.controls;
  }


  getProcessType() {
    if ((this.policyDetails.locCode && this.policyDetails.type === 'COMMON') || this.policyDetails.type === 'SPECIFIC') {
      return false;
    } else if (this.policyDetails.locCode === undefined && this.policyDetails.type === 'COMMON') {
      return true;
    }
  }

  getMasterData(key) {
    this.gdmsService.getMasterdata(key, {}).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        if (res.data.masterdata.key === 'LOCATION_TYPE') {
          this.locationTypes = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'SBU') {
          this.sbus = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DEPARTMENT') {
          this.departments = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'USER_ROLES') {
          this.allRoles = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DM_CLASSIFICATION') {
          this.classificationTypes = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DM_POLI_CATEGORY') {
          this.proCategories = res.data.masterdata.options;
        }
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.cd.detectChanges();
    },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getPolicyBydocId() {
    this.loading = true;
    this.gdmsService.getPolicyDetailsBydocId(this.subKey, this.policyDocId, {}).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        this.policyDetails = res.data.policy;
        if (res.data.policy.originType === 'ISSUE' || res.data.policy.originType === 'REVISION') {
          this.createForm.get('notes').setValidators(Validators.required);
        } else {
          this.createForm.get('notes').clearValidators();
        }

        this.createForm.patchValue({
          title: res.data.policy.title,
          desc: res.data.policy.desc,
          attachments: res.data.policy.attachments ? res.data.policy.attachments : [],
          notes: res.data.policy.notes ? res.data.policy.notes : ""
        });
        if (this.proCategories.length > 0) {
          this.createForm.patchValue({
            category: this.proCategories.filter(val => { return val.value === res.data.policy.category; })[0]
          });
        }
        if (this.classificationTypes.length > 0) {
          this.createForm.patchValue({
            classification: this.classificationTypes.filter(val => { return val.value === res.data.policy.classification; })[0]
          });
        }
        this.getPolicyApprovalHistory();
        this.loading = false;
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  fileUpload(event) {
    if (event.target.files[0].type === "application/pdf") {
      let file = event.target.files[0];
      let params = { key: file.name };
      this.loading = true;
      this.gdmsService.fileUpload({ params }).subscribe(res => {
        this.createForm.patchValue({
          attachments: [{
            url: res.body.Bucketpath,
            key: file.name,
            contentType: file.type,
            fileName: file.name,
            size: file.size,
          }]
        });
        this.autoSavePolicy();
        this.loading = false;
        if (res.body && res.body.preSignedUrl !== '') {
          this.gdmsService.uploadUrl(res.body.preSignedUrl, file)
            .subscribe((res: any) => {
              this.createForm.patchValue({
                attachments: [{
                  url: res.body.Bucketpath,
                  key: file.name,
                  contentType: file.type,
                  fileName: file.name,
                  size: file.size,
                }]
              });
              this.autoSavePolicy();
              this.loading = false;
              this.commonUtilityService.showSuccessMessage('File uploaded');
            }, (err) => {
              this.loading = false;
              // this.commonUtilityService.singleErrorMsg({
              //   error: { message: 'Upload failed' },
              // });
            });
        }
      }, (err) => {
        this.loading = false;
      });
    } else {
      this.loading = false;
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Upload PDF Only' },
      });
    }
  }

  formatBytes(bytes: any, decimals?: any) {
    if (bytes) {
      if (bytes === 0) {
        return '0 Bytes';
      }
      const k = 1024;
      const dm = decimals <= 0 ? 0 : decimals || 2;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
  }


  // To filter formats in procedures tab
  filterFormat(event: any) {
    // this.loading = true;
    // this.intranetService
    //   .getFormats({
    //     params: {
    //       searchText: event.query ? event.query : '',
    //     },
    //     headers: { context: 'ADMIN_SEARCH_ACTIVE_STATUS_FORMATS' },
    //   })
    //   .subscribe(
    //     (res: any) => {
    //       this.loading = false;
    //       if (this.procedure.formats && this.procedure.formats.length > 0) {
    //         let result = res.formatList.filter(
    //           (obj1: any) =>
    //             !this.procedure.formats.some(
    //               (obj2: any) => obj2.docNo === obj1.docNo
    //             )
    //         );
    //         this.activeFormats = result;
    //       } else {
    //         this.activeFormats = res.formatList;
    //       }
    //       if(res['status'] === 'FAILURE'){
    //         this.commonService.showErrorMessage(res);
    //       }
    //     },
    //     (err: any) => {
    //       this.loading = false;
    //       this.commonService.showErrorMessage(err);
    //     }
    //   );
  }

  // To add new format to procedure

  discardPolicy() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Delete?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.createForm.patchValue({
          attachments: ''
        });
      },
      reject: (type) => {

      },
    });

  }

  discardProORFormat() {
    // if (this.createForm.value)
  }

  autoSavePolicy() {
    let data = {
      docId: this.policyDetails.docId,
      title: this.createForm.value.title,
      desc: this.createForm.value.desc,
      classification: this.createForm.value.classification ? this.createForm.value.classification.value : '',
      category: this.createForm.value.category ? this.createForm.value.category.value : '',
      attachments: this.createForm.value.attachments ? this.createForm.value.attachments : [],
      notes: this.createForm.value.notes ? this.createForm.value.notes : ''
    };
    this.gdmsService.savePolicy({ data }).subscribe((res) => {
      if (res.status === 'SUCCESS') {

      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err: any) => {
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }


  save() {
    this.loading = true;
    let data = {
      docId: this.policyDetails.docId,
      title: this.createForm.value.title,
      desc: this.createForm.value.desc,
      classification: this.createForm.value.classification ? this.createForm.value.classification.value : '',
      category: this.createForm.value.category ? this.createForm.value.category.value : '',
      attachments: this.createForm.value.attachments ? this.createForm.value.attachments : [],
      notes: this.createForm.value.notes ? this.createForm.value.notes : ''
    };
    this.gdmsService.savePolicy({ data }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.commonUtilityService.showSuccessMessage('Saved Successfully!');
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.loading = false;
    },
      (err: any) => {
        this.commonUtilityService.showErrorMessage(err);
        this.loading = false;
      }
    );
  }

  onSubmit() {
    if (this.createForm.invalid) {
      return;
    } else {
      this.confirmSubmit();
    }
  }


  confirmSubmit() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Submit?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        let data = {
          docId: this.policyDetails.docId,
          title: this.createForm.value.title,
          desc: this.createForm.value.desc,
          classification: this.createForm.value.classification ? this.createForm.value.classification.value : '',
          category: this.createForm.value.category ? this.createForm.value.category.value : '',
          attachments: this.createForm.value.attachments ? this.createForm.value.attachments : [],
          notes: this.createForm.value.notes ? this.createForm.value.notes : ''
        };
        this.loading = true;
        this.gdmsService.submitPolicy({ data }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            // this.policyDetails = Object.assign(this.policyDetails, res.data.policy);
            this.getPolicyBydocId();
            this.getPolicyApprovalHistory();
            this.getSidenav();
            this.router.navigateByUrl(`gdms/admin/policies/pendings/${res.data.policy.docId}`);
            this.loading = false;
            window.scroll(0, 0);
            if (this.parentPathName.name === 'admin') {
              this.router.navigateByUrl(`gdms/admin/policies/pendings/${res.data.policy.docId}`);
              return;
            }
            if (this.parentPathName.name === 'site') {
              this.router.navigateByUrl(`gdms/site/policies/pendings/${res.data.policy.docId}`);
              return;
            }
          } else {
            this.commonUtilityService.showErrorMessage(res);
            this.loading = false;
          }
        },
          (err) => {
            this.commonUtilityService.showErrorMessage(err);
            this.loading = false;
          }
        );
      },
      reject: (type) => {

      },
    });
  }


  approvePolicy() {
    this.approveVisible = true;
  }

  confirmApprove() {
    if (this.policyDetails.action === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required Action' },
      });
      return;
    } else if (this.policyDetails.remarks === '' || this.policyDetails.remarks === null || this.policyDetails.remarks === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required Remarks' },
      });
      return;
    } else {
      this.loading = true;
      let data = {
        docId: this.policyDetails.docId,
        action: this.policyDetails.action.key,
        remarks: this.policyDetails.remarks,
      };
      this.gdmsService.approvePolicy({ data }).subscribe((res) => {
        if (res.status === 'SUCCESS') {
          this.getPolicyBydocId();
          this.getSidenav();
          this.loading = false;
          window.scroll(0, 0);
          this.approveVisible = false;
          if (this.parentPathName.name === 'admin') {
            if (this.policyDetails.action.key === 'APPROVE') {
              this.router.navigateByUrl(`gdms/admin/policies/pendings/${this.policyDetails.docId}`);
              return;
            }
            if (this.policyDetails.action.key === 'REJECT') {
              this.router.navigateByUrl(`gdms/admin/policies/drafts/${this.policyDetails.docId}`);
              return;
            }
          }
          if (this.parentPathName.name === 'site') {
            if (this.policyDetails.action.key === 'APPROVE') {
              this.router.navigateByUrl(`gdms/site/policies/pendings/${this.policyDetails.docId}`);
              return;
            }
            if (this.policyDetails.action.key === 'REJECT') {
              this.router.navigateByUrl(`gdms/site/policies/drafts/${this.policyDetails.docId}`);
              return;
            }
          }
        } else {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      },
        (err) => {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }

  close() {
    this.approveVisible = false;
    this.policyDetails.action = "";
    this.policyDetails.remarks = "";
    this.policyDetails.reviewDate = "";
  }

  publish() {
    this.policyDetails.reviewDate = "";
    this.policyDetails.effectiveDate = "";
    this.policyDetails.issueDate = "";
    this.approveVisible = true;
  }

  confirmPublish() {
    if (this.policyDetails.reviewDate === '' || this.policyDetails.reviewDate === undefined || this.policyDetails.effectiveDate === '' || this.policyDetails.effectiveDate === undefined || this.policyDetails.issueDate === '' || this.policyDetails.issueDate === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required All Fields' },
      });
      return;
    } else {
      this.loading = true;
      this.gdmsService.publishPolicy({
        data: {
          docId: this.policyDetails.docId,
          reviewDate: moment(this.policyDetails.reviewDate).format('DD-MMM-YYYY'),
          effectiveDate: moment(this.policyDetails.effectiveDate).format('DD-MMM-YYYY'),
          issueDate: moment(this.policyDetails.issueDate).format('DD-MMM-YYYY')
        },

      }).subscribe((res) => {
        if (res.status === 'SUCCESS') {
          this.policyDetails = res.data.policy;
          this.policyDetails = Object.assign(this.policyDetails, res.data.policy);
          this.approveVisible = false;
          this.subKey = { name: 'published', value: 'PUBLISHED' };
          this.getPolicyApprovalHistory();
          this.getSidenav();
          if (this.parentPathName.name === 'admin') {
            this.router.navigateByUrl(`/gdms/admin/policies/published/${res.data.policy.docId}`);
            this.loading = false;
            return;
          }
          if (this.parentPathName.name === 'site') {
            this.router.navigateByUrl(`/gdms/site/policies/published/${res.data.policy.docId}`);
            this.loading = false;
            return;
          }
          this.loading = false;
          window.scroll(0, 0);
        } else {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      },
        (err) => {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }


  discard() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Discard?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.gdmsService.discardPolicy({ params: { docId: this.policyDetails.docId } }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            this.getSidenav();
            if (this.parentPathName.name === 'admin') {
              this.router.navigateByUrl(`/gdms/admin/policies/${this.subKey.name}/list`);
              return;
            }
            if (this.parentPathName.name === 'site') {
              this.router.navigateByUrl(`/gdms/site/policies/${this.subKey.name}/list`);
            }
          } else {
            this.commonUtilityService.showErrorMessage(res);
          }
        },
          (err) => {
            this.commonUtilityService.showErrorMessage(err);
          }
        );
      },
      reject: (type) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            break;
          case ConfirmEventType.CANCEL:
            break;
        }
      },
    });
  }

  getPolicyApprovalHistory() {
    this.histLoading = true;
    this.gdmsService.getPolicyApprovalHistory(this.subKey, {
      params: { docId: this.policyDetails.docId },
    }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.approvalsHistory = res.data.hist;
        this.cd.detectChanges();
        this.histLoading = false;
      } else {
        this.histLoading = false;
        this.commonUtilityService.showErrorMessage(res);
      }

    },
      (err) => {
        this.histLoading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getSidenav() {
    this.gdmsService.getDmSideNav({
    }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        if (this.parentPathName.name === 'admin') {
          res.data.nav.forEach(val => {
            if (val.value === 'ADMIN') {
              val.expanded = true;
            }
          });
        }
        if (this.parentPathName.name === 'site') {
          res.data.nav.forEach(val => {
            if (val.value === 'SITE') {
              val.expanded = true;
            }
          });
        }
        this.navData = res.data.nav;
        this.gdmsService.updateSideNav(this.navData);
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    }, (err) => {
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  parentCodeClick() {
    this.loading = true;
    let params: any = {
      code: this.policyDetails.code,
      version: this.policyDetails.commonVersion
    };
    this.gdmsService.getCommonParentDocId({ params }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        window.open(`/gdms/admin/published/${res.data.policy.docId}`, "_blank");
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.loading = false;
    }, (err) => {
      this.loading = false;
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  goToBack() {
    if (this.allPolicysList) {
      this.router.navigateByUrl(`/gdms/policies`);
      return;
    }
    if (this.parentPathName.name === 'admin') {
      this.router.navigateByUrl(`/gdms/admin/policies/${this.subKey.name}/list`);
      return;
    }
    if (this.parentPathName.name === 'site') {
      this.router.navigateByUrl(`/gdms/site/policies/${this.subKey.name}/list`);
    }

  }
  hidePreview() {
    this.preImageUrl = "";
  }

  preview(preUrl) {
    this.preHeader = preUrl.fileName;
    this.preImageUrl = preUrl.url;
    this.visiblePdf = true;
  }

  openDialog(dialog: Dialog) {
    dialog.maximized = true;
  }



}
