import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DmProcedureDetailsComponent } from './dm-procedure-details.component';

describe('DmProcedureDetailsComponent', () => {
  let component: DmProcedureDetailsComponent;
  let fixture: ComponentFixture<DmProcedureDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DmProcedureDetailsComponent]
    });
    fixture = TestBed.createComponent(DmProcedureDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
