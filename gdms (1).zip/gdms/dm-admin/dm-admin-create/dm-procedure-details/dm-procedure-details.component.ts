import { Component, ViewChild, OnInit, ChangeDetectorRef, ElementRef, Renderer2 } from '@angular/core';
import { FormArray, FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GdmsService } from '../../../gdms-services/gdms.service';
import { CommonUtilityService } from 'src/app/services/common-utility.service';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ConfirmationService, MessageService, ConfirmEventType } from 'primeng/api';
import { SafeResourceUrl, DomSanitizer } from "@angular/platform-browser";
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { NgForm } from '@angular/forms';
import { Dialog } from 'primeng/dialog';

@Component({
  selector: 'app-dm-procedure-details',
  templateUrl: './dm-procedure-details.component.html',
  styleUrls: ['./dm-procedure-details.component.scss']
})
export class DmProcedureDetailsComponent implements OnInit {

  files: any = [];
  checked: boolean = false;
  procedure: any = {
    formats: [{ "id": "64e9c46d82adc880cf2214e2", "title": "Format Details Title - One", "docNo": "Format-1", "categoryName": "Project Management Cell", "categoryValue": "PMC", "classificationName": "Protected", "classificationValue": "PROTECTED", "issueNo": "123", "issueDate": "17 Aug 2023", "revisionNo": "1", "effectiveDate": "25 Aug 2023", "attachments": [{ "fileName": "523 (2).pdf", "url": "https://greenkotest.s3.ap-south-1.amazonaws.com/Formats/2023/08/26/523%20%282%29.pdf", "contentType": "application/pdf", "size": 76309, "cover": false }], "activeStatus": true, "createdAt": "26-Aug-2023 09:22:53", "updatedAt": "26-Aug-2023 09:54:21", "createdBy": "Girish M", "updatedBy": "Girish M" }, { "id": "64e9c54382adc880cf2214ee", "title": "Format Details Title - Four", "docNo": "Format-4", "categoryName": "GAM-Solar", "categoryValue": "GAMS", "classificationName": "Restricted", "classificationValue": "RESTRICTED", "issueNo": "345", "issueDate": "18 Aug 2023", "revisionNo": "678", "effectiveDate": "19 Aug 2027", "attachments": [{ "fileName": "29-MAY-2023_RAID Tracker (2) (1).xlsx", "url": "https://greenkotest.s3.ap-south-1.amazonaws.com/Formats/2023/08/26/29-MAY-2023_RAID%20Tracker%20%282%29%20%281%29.xlsx", "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "size": 27436, "cover": false }], "activeStatus": true, "createdAt": "26-Aug-2023 09:26:27", "updatedAt": "26-Aug-2023 09:28:17", "createdBy": "Girish M", "updatedBy": "Girish M" }]
  };
  activeFormats: any = [];
  submitted: boolean = false;
  @ViewChild('content') elementView: ElementRef;
  contentHeight: number;
  procedureDocId: any;
  createProcedureForm: FormGroup;
  createFormatForm: FormGroup;
  loading: boolean = false;
  histLoading: boolean = false;
  locationTypes: any = [];
  sbus: any = [];
  departments: any = [];
  allRoles: any = [];
  subKey: any;
  navData: any = [];
  validateAll: boolean = false;
  disableSubmitBtn: boolean = true;
  approveVisible: boolean = false;
  procedureDetails: any = {};
  actions: any = [
    { name: 'Approve', key: 'APPROVE' },
    { name: 'Reject', key: 'REJECT' },
  ];
  minDate: any = new Date();
  parentPathName: any;
  historyFlag: boolean = false;
  urlSafe: SafeResourceUrl;
  classificationTypes: any = [];
  proCategories: any = [];
  subType: any;
  approvalsHistory: any = [];
  preHeader: any;
  visiblePdf: boolean = false;
  preImageUrl;
  formatDialog: boolean = false;
  linkFormatDialog: boolean = false;
  allFormats: any;
  refFormats: any = [];
  searchFormat: any;
  formatViewDialog: boolean = false;
  allProcedureList: any;
  subKeyList: any = [];
  currentPathList: any;
  constructor (private fb: FormBuilder,
    private route: ActivatedRoute,
    private gdmsService: GdmsService,
    private commonUtilityService: CommonUtilityService,
    private cd: ChangeDetectorRef,
    private router: Router,
    private httpClient: HttpClient,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private sanitizer: DomSanitizer, private renderer: Renderer2) {

    this.getMasterData('DM_PROC_CATEGORY');
    this.getMasterData('DM_CLASSIFICATION');

  }

  onResize(ev) {
    this.contentHeight = ev.contentRect.height + 67.75;
    // if (ev.contentRect.width < 500) {
    //   this.renderer.setStyle(ev.target, 'background', 'red');
    // } else {
    //   this.renderer.removeStyle(ev.target, 'background');
    // }
  }


  ngOnInit(): void {
    this.subKeyList = [{ name: 'drafts', value: 'DRAFTS' }, { name: 'pendings', value: 'PENDING_WITH_ME' }, { name: 'reviews', value: 'PENDING_IN_REVIEW' }, { name: 'published', value: 'PUBLISHED' }];
    let parentPathList = [{ name: 'admin', value: 'ADMIN' }, { name: 'site', value: 'SITE' }];
    this.currentPathList = this.router.url.split('/');
    this.allProcedureList = this.currentPathList.includes('all');
    this.subKey = this.subKeyList.filter(value => this.currentPathList.includes(value.name))[0];
    let subTypesList = [{ name: 'policies', value: 'POLICIES' }, { name: 'procedures', value: 'PROCEDURES' }, { name: 'formats', value: 'FORMATS' }];
    this.subType = subTypesList.filter(value => this.currentPathList.includes(value.name))[0];
    this.parentPathName = parentPathList.filter(value => this.currentPathList.includes(value.name))[0];
    this.historyFlag = this.currentPathList.includes('history');
    this.procedureDocId = this.route.snapshot.paramMap.get('id');
    if (this.procedureDocId) {
      // this.getMasterData('LOCATION_TYPE');
      // this.getMasterData('SBU');
      this.getProcedureCreateForm();
      this.getFormatCreateForm();
      setTimeout(() => {
        this.getProcedureBydocId();
      }, 300);
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl('');
    }
  }

  getProcedureCreateForm() {
    this.createProcedureForm = this.fb.group({
      title: ['', Validators.required],
      classification: ['', Validators.required],
      category: ['', Validators.required],
      desc: ['', Validators.required],
      attachments: ['', Validators.required],
      annexures: [''],
      action: [''],
      remarks: [''],
      reviewDate: [''],
      notes: ['', this.procedureDetails && (this.procedureDetails.originType === 'ISSUE' || this.procedureDetails.originType === 'REVISION') ? Validators.required : []],
    });
  }

  getFormatCreateForm() {
    this.createFormatForm = this.fb.group({
      docId: [''],
      formatTitle: ['', Validators.required],
      formatDesc: ['', Validators.required],
      formatAttachments: [, Validators.required],
    });
  }

  get f() {
    return this.createProcedureForm.controls;
  }


  getProcessType() {
    if ((this.procedureDetails.locCode && this.procedureDetails.type === 'COMMON') || this.procedureDetails.type === 'SPECIFIC') {
      return false;
    } else if (this.procedureDetails.locCode === undefined && this.procedureDetails.type === 'COMMON') {
      return true;
    }
  }

  getMasterData(key) {
    // this.loading = true;
    this.gdmsService.getMasterdata(key, {}).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        if (res.data.masterdata.key === 'LOCATION_TYPE') {
          this.locationTypes = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'SBU') {
          this.sbus = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DEPARTMENT') {
          this.departments = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'USER_ROLES') {
          this.allRoles = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DM_CLASSIFICATION') {
          this.classificationTypes = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DM_PROC_CATEGORY') {
          this.proCategories = res.data.masterdata.options;
        }
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      // this.loading = false;
      this.cd.detectChanges();
    },
      (err) => {
        // this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getProcedureBydocId() {
    this.loading = true;
    this.gdmsService.getProcedureDetailsBydocId(this.subKey, this.procedureDocId, {}).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        this.loading = false;
        this.procedureDetails = res.data.procedure;
        this.refFormats = res.data.procedure.refFormats;
        this.createProcedureForm.patchValue({
          title: res.data.procedure.title,
          desc: res.data.procedure.desc,
          attachments: res.data.procedure.attachments ? res.data.procedure.attachments : [],
          annexures: res.data.procedure.annexures ? res.data.procedure.annexures : [],
        });
        if (this.proCategories.length > 0) {
          this.createProcedureForm.patchValue({
            category: this.proCategories.filter(val => { return val.value === res.data.procedure.category; })[0]
          });
        }
        if (this.classificationTypes.length > 0) {
          this.createProcedureForm.patchValue({
            classification: this.classificationTypes.filter(val => { return val.value === res.data.procedure.classification; })[0]
          });
        }
        this.getProcedureApprovalHistory();
        this.getAllFormats(this.procedureDetails);
      } else {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getAllFormats(procedureDetails) {
    const params = {
      procedureDocId: procedureDetails.docId
    };
    if (this.procedureDetails.status === 'PUBLISHED') {
      this.subKey = { name: 'published', value: 'PUBLISHED' };
    } else {
      this.subKey = this.subKeyList.filter(value => this.currentPathList.includes(value.name))[0];
    }
    this.gdmsService.getLinkedFormats(this.subKey, { params }).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        this.allFormats = res.data.formats;
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
      }
    );
    // this.cd.detectChanges();
  }

  fileUpload(event) {
    if (event.target.files[0].type === "application/pdf") {
      let file = event.target.files[0];
      let params = { key: file.name };
      this.loading = true;
      this.gdmsService.fileUpload({ params }).subscribe(res => {
        if (res.body && res.body.preSignedUrl !== '') {
          this.createProcedureForm.patchValue({
            attachments: [{
              url: res.body.Bucketpath,
              key: file.name,
              contentType: file.type,
              fileName: file.name,
              size: file.size,
            }]
          });
          this.autoSaveProcedure();
          this.loading = false;
          this.gdmsService.uploadUrl(res.body.preSignedUrl, file)
            .subscribe((res: any) => {
              this.createProcedureForm.patchValue({
                attachments: [{
                  url: res.body.Bucketpath,
                  key: file.name,
                  contentType: file.type,
                  fileName: file.name,
                  size: file.size,
                }]
              });
              this.autoSaveProcedure();
              this.loading = false;
              this.commonUtilityService.showSuccessMessage('File uploaded');
            }, (err) => {
              this.loading = false;
              // this.commonUtilityService.singleErrorMsg({
              //   error: { message: 'Upload failed' },
              // });
            });
        }
      }, (err) => {
        this.loading = false;
      });
    } else {
      this.loading = false;
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Upload PDF Only' },
      });
    }
  }

  annexurefileUpload(event) {
    if (event.target.files[0].type === "application/pdf") {
      let file = event.target.files[0];
      let params = { key: file.name };
      this.loading = true;
      this.gdmsService.fileUpload({ params }).subscribe(res => {
        if (res.body && res.body.preSignedUrl !== '') {
          this.createProcedureForm.patchValue({
            annexures: [{
              url: res.body.Bucketpath,
              key: file.name,
              contentType: file.type,
              fileName: file.name,
              size: file.size,
            }]
          });
          this.autoSaveProcedure();
          this.loading = false;
          this.gdmsService.uploadUrl(res.body.preSignedUrl, file)
            .subscribe((res: any) => {
              this.createProcedureForm.patchValue({
                annexures: [{
                  url: res.body.Bucketpath,
                  key: file.name,
                  contentType: file.type,
                  fileName: file.name,
                  size: file.size,
                }]
              });
              this.autoSaveProcedure();
              this.loading = false;
              this.commonUtilityService.showSuccessMessage('File uploaded');
            }, (err) => {
              this.loading = false;
              // this.commonUtilityService.singleErrorMsg({
              //   error: { message: 'Upload failed' },
              // });
            });
        }
      }, (err) => {
        this.loading = false;
      });
    } else {
      this.loading = false;
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Upload PDF Only' },
      });
    }
  }

  formatFileUpload(event) {
    if (event.target.files[0].type === "application/pdf") {
      let file = event.target.files[0];
      let params = { key: file.name };
      this.loading = true;
      this.gdmsService.fileUpload({ params }).subscribe(res => {
        if (res.body && res.body.preSignedUrl !== '') {
          this.createFormatForm.patchValue({
            formatAttachments: [{
              url: res.body.Bucketpath,
              key: file.name,
              contentType: file.type,
              fileName: file.name,
              size: file.size,
            }]
          });
          this.loading = false;
          this.gdmsService.uploadUrl(res.body.preSignedUrl, file)
            .subscribe((res: any) => {
              this.createFormatForm.patchValue({
                formatAttachments: [{
                  url: res.body.Bucketpath,
                  key: file.name,
                  contentType: file.type,
                  fileName: file.name,
                  size: file.size,
                }]
              });
              this.loading = false;
              this.commonUtilityService.showSuccessMessage('File uploaded');
            }, (err) => {
              this.loading = false;
              // this.commonUtilityService.singleErrorMsg({
              //   error: { message: 'Upload failed' },
              // });
            });
        }
      }, (err) => {
        this.loading = false;
      });
    } else {
      this.loading = false;
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Upload PDF Only' },
      });
    }
  }

  formatBytes(bytes: any, decimals?: any) {
    if (bytes) {
      if (bytes === 0) {
        return '0 Bytes';
      }
      const k = 1024;
      const dm = decimals <= 0 ? 0 : decimals || 2;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
  }


  // To filter formats in procedures tab
  filterFormat(event: any) {
    this.loading = true;
    let subKey = { name: 'published', value: 'PUBLISHED' };
    this.gdmsService.getFormats(subKey, {
      params: {
        searchText: event.query ? event.query : '',
        mainKey: this.parentPathName.value,
      }
    }).subscribe((res: any) => {
      if (res.status === 'SUCCESS') {
        this.loading = false;
        this.activeFormats = res.data.formats;
        if (this.allFormats.refFormats && this.allFormats.refFormats.length > 0) {
          let result = res.data.formats.filter((obj1: any) =>
            !this.allFormats.refFormats.some((obj2: any) => obj2.fmtDocNo === obj1.fmtDocNo));
          this.activeFormats = result;
        } else {
          this.activeFormats = res.data.formats;
        }
      } else {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err: any) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  //Form a List
  tempList: any = [];
  addToList(format: any) {
    if (format) {
      this.tempList.push(format);
      this.searchFormat = "";
    }
  }


  // To add new format to procedure
  addActiveFormat(format: any) {
    if (format) {
      if (!this.procedureDetails.hasOwnProperty('formats')) {
        this.procedureDetails.formats = [];
      }
      // this.procedureDetails.formats.push(format);
      this.refFormats.push(format.fmtDocNo);
      this.searchFormat = "";
      // this.linkFormatDialog = false;
      this.autoSaveProcedure();
      this.getAllFormats(this.procedureDetails);
      // this.createProcedureForm.patchValue({
      //   searchFormat: ''
      // });
      this.tempList.pop(format);
    }
  }


  toggleForm(type: any) {
    if (type === 'add') {
      this.procedure = {};
      this.procedure.id = '';
      this.checked = false;
    } else if (type === 'cancel') {
      this.procedure = {};
      this.procedure.id = '';
      this.checked = false;
      // this.getProcedures({
      //   rows: this.procedureEvent ? this.procedureEvent.rows : 10,
      //   first: this.procedureEvent ? this.procedureEvent.first : 0,
      // });
    }
  }


  discardProcedureFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Delete?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.createProcedureForm.patchValue({
          attachments: ''
        });
      },
      reject: (type) => {

      },
    });
  }

  discardFormatFile() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Delete?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.createFormatForm.patchValue({
          formatAttachments: ''
        });
      },
      reject: (type) => {

      },
    });
  }

  discardAnnexure() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Delete?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.createProcedureForm.patchValue({
          annexures: ''
        });
      },
      reject: (type) => {

      },
    });
  }

  discardFormat(format) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Discard?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.loading = true;
        this.gdmsService.discardFormat({ params: { docId: format.docId } }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            this.getAllFormats(this.procedureDetails);
          } else {
            this.commonUtilityService.showErrorMessage(res);
          }
          this.loading = false;
        },
          (err) => {
            this.loading = false;
            this.commonUtilityService.showErrorMessage(err);
          }
        );
      },
      reject: (type) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            break;
          case ConfirmEventType.CANCEL:
            break;
        }
      },
    });
  }

  autoSaveProcedure() {
    let data = {
      docId: this.procedureDetails.docId,
      title: this.createProcedureForm.value.title,
      desc: this.createProcedureForm.value.desc,
      classification: this.createProcedureForm.value.classification ? this.createProcedureForm.value.classification.value : '',
      category: this.createProcedureForm.value.category ? this.createProcedureForm.value.category.value : '',
      attachments: this.createProcedureForm.value.attachments ? this.createProcedureForm.value.attachments : [],
      annexures: this.createProcedureForm.value.annexures ? this.createProcedureForm.value.annexures : [],
      notes: this.createProcedureForm.value.notes ? this.createProcedureForm.value.notes : '',
      refFormats: this.refFormats
    };
    this.loading = true;
    this.gdmsService.saveProcedure({ data }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.getAllFormats(res.data.procedure);
        this.loading = false;
      } else {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err: any) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  saveProcedure() {
    let data = {
      docId: this.procedureDetails.docId,
      title: this.createProcedureForm.value.title,
      desc: this.createProcedureForm.value.desc,
      classification: this.createProcedureForm.value.classification ? this.createProcedureForm.value.classification.value : '',
      category: this.createProcedureForm.value.category ? this.createProcedureForm.value.category.value : '',
      attachments: this.createProcedureForm.value.attachments ? this.createProcedureForm.value.attachments : [],
      annexures: this.createProcedureForm.value.annexures ? this.createProcedureForm.value.annexures : [],
      notes: this.createProcedureForm.value.notes ? this.createProcedureForm.value.notes : '',
      refFormats: this.refFormats
    };
    this.loading = true;
    this.gdmsService.saveProcedure({ data }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.commonUtilityService.showSuccessMessage('Saved Successfully!');
        this.getAllFormats(res.data.procedure);
        this.loading = false;
      } else {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err: any) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  saveFormat() {
    let data = {
      procedureDocId: this.procedureDetails.docId ? this.procedureDetails.docId : "", // save
      docId: this.createFormatForm.value.docId ? this.createFormatForm.value.docId : "", // update
      title: this.createFormatForm.value.formatTitle,
      desc: this.createFormatForm.value.formatDesc,
      attachments: this.createFormatForm.value.formatAttachments ? this.createFormatForm.value.formatAttachments : [],
    };
    this.loading = true;
    this.gdmsService.createFormat({ data }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.formatDialog = false;
        this.getAllFormats(this.procedureDetails);
        this.commonUtilityService.showSuccessMessage(res.data.message);
        this.loading = false;
      } else {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err: any) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  EditFormat(format) {
    this.loading = true;
    this.gdmsService.getFormatDetailsBydocId(this.subKey, format.docId, {}).subscribe(res => {
      if (res.status === 'SUCCESS') {
        this.createFormatForm.patchValue({
          docId: res.data.format.docId,
          formatTitle: res.data.format.title,
          formatDesc: res.data.format.desc,
          formatAttachments: res.data.format.attachments,
        });
        this.formatDialog = true;
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.loading = false;
    },
      (err: any) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
    // let data = {
    //   docId: format.docId,
    //   title: this.createFormatForm.value.formatTitle,
    //   desc: this.createFormatForm.value.formatDesc,
    //   attachments: this.createFormatForm.value.formatAttachments ? this.createFormatForm.value.formatAttachments : [],
    // };
    // this.gdmsService.createFormat({ data }).subscribe((res) => {
    //   if (res.status === 'SUCCESS') {
    //     this.formatDialog = false;
    //     this.getAllFormats();
    //     this.commonUtilityService.showSuccessMessage(res.data.message);
    //   } else {
    //     this.commonUtilityService.showErrorMessage(res);
    //   }
    // },
    //   (err: any) => {
    //     this.commonUtilityService.showErrorMessage(err);
    //   }
    // );
  }

  unlinkFormat(format) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Delete?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        let index = this.procedureDetails.refFormats.indexOf(format.fmtDocNo);
        this.procedureDetails.refFormats.splice(index, 1);
        this.autoSaveProcedure();
      },
      reject: (type) => {

      },
    });

  }

  onSubmit() {
    if (this.createProcedureForm.invalid) {
      return;
    } else {
      this.confirmSubmit();
    }
  }


  confirmSubmit() {
    if (this.procedureDetails.originType === 'ISSUE' || this.procedureDetails.originType === 'REVISION') {
      if (this.allFormats && this.allFormats.formats && this.allFormats.formats.length > 0) {
        let arr = this.allFormats.formats.filter(val => { return val.attachments === null; });
        if (arr.length > 0) {
          this.commonUtilityService.singleErrorMsg({
            error: { message: 'Required Format Attchment' },
          });
          return;
        }
      }
    }
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Submit?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.loading = true;
        let data = {
          docId: this.procedureDetails.docId,
          title: this.createProcedureForm.value.title,
          desc: this.createProcedureForm.value.desc,
          classification: this.createProcedureForm.value.classification ? this.createProcedureForm.value.classification.value : '',
          category: this.createProcedureForm.value.category ? this.createProcedureForm.value.category.value : '',
          attachments: this.createProcedureForm.value.attachments ? this.createProcedureForm.value.attachments : [],
          annexures: this.createProcedureForm.value.annexures ? this.createProcedureForm.value.annexures : [],
          notes: this.createProcedureForm.value.notes ? this.createProcedureForm.value.notes : '',
          refFormats: this.refFormats,
          action: "APPROVE",
          remarks: "YES"

        };
        this.gdmsService.submitProcedure({ data }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            this.procedureDetails = Object.assign(this.procedureDetails, res.data.procedure);
            this.getAllFormats(this.procedureDetails);
            this.getSidenav();
            this.getProcedureApprovalHistory();
            this.router.navigateByUrl(`gdms/admin/procedures/pendings/${res.data.procedure.docId}`);
            this.loading = false;
            if (this.parentPathName.name === 'admin') {
              this.router.navigateByUrl(`gdms/admin/procedures/pendings/${res.data.procedure.docId}`);
              return;
            }
            if (this.parentPathName.name === 'site') {
              this.router.navigateByUrl(`gdms/site/procedures/pendings/${res.data.procedure.docId}`);
              return;
            }
          } else {
            this.commonUtilityService.showErrorMessage(res);
            this.loading = false;
          }
        },
          (err) => {
            this.commonUtilityService.showErrorMessage(err);
            this.loading = false;
          }
        );
      },
      reject: (type) => {

      },
    });
  }


  approveProcedure() {
    this.approveVisible = true;
  }

  confirmApprove() {
    if (this.procedureDetails.action === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required Action' },
      });
      return;
    } else if (this.procedureDetails.remarks === '' || this.procedureDetails.remarks === null || this.procedureDetails.remarks === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required Remarks' },
      });
      return;
    } else {
      this.loading = true;
      let data = {
        docId: this.procedureDetails.docId,
        action: this.procedureDetails.action.key,
        remarks: this.procedureDetails.remarks,
      };
      this.gdmsService.approveProcedure({ data }).subscribe((res) => {
        if (res.status === 'SUCCESS') {
          this.getProcedureBydocId();
          this.getAllFormats(this.procedureDetails);
          this.getSidenav();
          this.loading = false;
          window.scroll(0, 0);
          this.approveVisible = false;
          if (this.parentPathName.name === 'admin') {
            if (this.procedureDetails.action.key === 'APPROVE') {
              this.router.navigateByUrl(`gdms/admin/procedures/pendings/${this.procedureDetails.docId}`);
              return;
            }
            if (this.procedureDetails.action.key === 'REJECT') {
              this.router.navigateByUrl(`gdms/admin/procedures/drafts/${this.procedureDetails.docId}`);
              return;
            }
          }
          if (this.parentPathName.name === 'site') {
            if (this.procedureDetails.action.key === 'APPROVE') {
              this.router.navigateByUrl(`gdms/site/procedures/pendings/${this.procedureDetails.docId}`);
              return;
            }
            if (this.procedureDetails.action.key === 'REJECT') {
              this.router.navigateByUrl(`gdms/site/procedures/drafts/${this.procedureDetails.docId}`);
              return;
            }
          }
        } else {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      },
        (err) => {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }

  close() {
    this.approveVisible = false;
    this.procedureDetails.action = "";
    this.procedureDetails.remarks = "";
    this.procedureDetails.reviewDate = "";
  }

  closeFormat() {
    this.createFormatForm.reset();
    this.formatDialog = false;
  }

  publish() {
    this.procedureDetails.reviewDate = "";
    this.procedureDetails.effectiveDate = "";
    this.procedureDetails.issueDate = "";
    this.approveVisible = true;
  }

  confirmPublish() {
    if (this.procedureDetails.reviewDate === '' || this.procedureDetails.reviewDate === undefined || this.procedureDetails.effectiveDate === '' || this.procedureDetails.effectiveDate === undefined || this.procedureDetails.issueDate === '' || this.procedureDetails.issueDate === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required All Fields' },
      });
      return;
    } else {
      this.loading = true;
      this.gdmsService.publishProcedure({
        data: {
          docId: this.procedureDetails.docId,
          reviewDate: moment(this.procedureDetails.reviewDate).format('DD-MMM-YYYY'),
          effectiveDate: moment(this.procedureDetails.effectiveDate).format('DD-MMM-YYYY'),
          issueDate: moment(this.procedureDetails.issueDate).format('DD-MMM-YYYY')
        },

      }).subscribe((res) => {
        if (res.status === 'SUCCESS') {
          this.procedureDetails = res.data.procedure;
          this.procedureDetails = Object.assign(this.procedureDetails, res.data.procedure);
          // this.getProcedureBydocId();
          this.getAllFormats(this.procedureDetails);
          this.approveVisible = false;
          this.subKey = { name: 'published', value: 'PUBLISHED' };
          this.getSidenav();
          this.getProcedureApprovalHistory();
          if (this.parentPathName.name === 'admin') {
            this.router.navigateByUrl(`/gdms/admin/procedures/published/${res.data.procedure.docId}`);
            this.loading = false;
            return;
          }
          if (this.parentPathName.name === 'site') {
            this.router.navigateByUrl(`/gdms/site/procedures/published/${res.data.procedure.docId}`);
            this.loading = false;
            return;
          }
          this.loading = false;
          window.scroll(0, 0);
        } else {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      },
        (err) => {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }


  discard() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Discard?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.loading = true;
        this.gdmsService.discardProcedure({ params: { docId: this.procedureDetails.docId } }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            this.getSidenav();
            if (this.parentPathName.name === 'admin') {
              this.router.navigateByUrl(`/gdms/admin/procedures/${this.subKey.name}/list`);
              return;
            }
            if (this.parentPathName.name === 'site') {
              this.router.navigateByUrl(`/gdms/site/procedures/${this.subKey.name}/list`);
            }
            this.loading = false;
          } else {
            this.loading = false;
            this.commonUtilityService.showErrorMessage(res);
          }
        },
          (err) => {
            this.loading = false;
            this.commonUtilityService.showErrorMessage(err);
          }
        );
      },
      reject: (type) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            break;
          case ConfirmEventType.CANCEL:
            break;
        }
      },
    });
  }

  getProcedureApprovalHistory() {
    this.histLoading = true;
    this.gdmsService.getProcedureApprovalHistory(this.subKey, {
      params: { docId: this.procedureDetails.docId },
    }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.approvalsHistory = res.data.hist;
        this.cd.detectChanges();
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.histLoading = false;
    },
      (err) => {
        this.histLoading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getSidenav() {
    this.gdmsService.getDmSideNav({
    }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        if (this.parentPathName.name === 'admin') {
          res.data.nav.forEach(val => {
            if (val.value === 'PROCEDURES') {
              val.expanded = true;
            }
          });
        }
        if (this.parentPathName.name === 'site') {
          res.data.nav.forEach(val => {
            if (val.value === 'SITE') {
              val.expanded = true;
            }
          });
        }
        this.navData = res.data.nav;
        this.gdmsService.updateSideNav(this.navData);
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    }, (err) => {
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  parentCodeClick() {
    this.loading = true;
    let params: any = {
      code: this.procedureDetails.code,
      version: this.procedureDetails.commonVersion
    };
    this.gdmsService.getCommonParentDocId({ params }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        window.open(`/gdms/admin/published/${res.data.procedure.docId}`, "_blank");
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.loading = false;
    }, (err) => {
      this.loading = false;
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  goToBack() {
    if (this.allProcedureList) {
      this.router.navigateByUrl(`/gdms/procedures`);
      return;
    }
    if (this.parentPathName.name === 'admin') {
      this.router.navigateByUrl(`/gdms/admin/procedures/${this.subKey.name}/list`);
      return;
    }
    if (this.parentPathName.name === 'site') {
      this.router.navigateByUrl(`/gdms/site/procedures/${this.subKey.name}/list`);
      return;
    }

  }

  hidePreview() {
    this.preImageUrl = "";
  }

  preview(preUrl) {
    this.preHeader = preUrl.fileName;
    this.preImageUrl = preUrl.url;
    this.visiblePdf = true;
  }

  openDialog(dialog: Dialog) {
    dialog.maximized = true;
  }

  openFormatDialog() {
    this.formatDialog = true;
    this.createFormatForm.reset();

  }
  openLinkFormatDialog() {
    this.searchFormat = "";
    this.linkFormatDialog = true;
  }

  viewFormat(format, status) {
    if (status === 'PUBLISH') {
      this.subKey = { name: 'published', value: 'PUBLISHED' };
    } else {
      this.subKey = this.subKeyList.filter(value => this.currentPathList.includes(value.name))[0];
    }
    this.loading = true;
    this.gdmsService.getFormatDetailsBydocId(this.subKey, format.docId, {}).subscribe(res => {
      if (res.status === 'SUCCESS') {
        this.createFormatForm.patchValue({
          docId: res.data.format.docId,
          formatTitle: res.data.format.title,
          formatDesc: res.data.format.desc,
          formatAttachments: res.data.format.attachments,
        });
        this.formatViewDialog = true;
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.loading = false;
    },
      (err: any) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );

  }


  closeFormatView() {
    this.formatViewDialog = false;
  }

}
