import { Component, ViewChild, OnInit, ChangeDetectorRef, ElementRef, Renderer2 } from '@angular/core';
import { FormArray, FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GdmsService } from '../../../gdms-services/gdms.service';
import { CommonUtilityService } from 'src/app/services/common-utility.service';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ConfirmationService, MessageService, ConfirmEventType } from 'primeng/api';
import { SafeResourceUrl, DomSanitizer } from "@angular/platform-browser";
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { NgForm } from '@angular/forms';
import { Dialog } from 'primeng/dialog';

@Component({
  selector: 'app-dm-format-details',
  templateUrl: './dm-format-details.component.html',
  styleUrls: ['./dm-format-details.component.scss']
})
export class DmFormatDetailsComponent implements OnInit {

  files: any = [];
  checked: boolean = false;
  procedure: any = {
    formats: [{ "id": "64e9c46d82adc880cf2214e2", "title": "Format Details Title - One", "docNo": "Format-1", "categoryName": "Project Management Cell", "categoryValue": "PMC", "classificationName": "Protected", "classificationValue": "PROTECTED", "issueNo": "123", "issueDate": "17 Aug 2023", "revisionNo": "1", "effectiveDate": "25 Aug 2023", "attachments": [{ "fileName": "523 (2).pdf", "url": "https://greenkotest.s3.ap-south-1.amazonaws.com/Formats/2023/08/26/523%20%282%29.pdf", "contentType": "application/pdf", "size": 76309, "cover": false }], "activeStatus": true, "createdAt": "26-Aug-2023 09:22:53", "updatedAt": "26-Aug-2023 09:54:21", "createdBy": "Girish M", "updatedBy": "Girish M" }, { "id": "64e9c54382adc880cf2214ee", "title": "Format Details Title - Four", "docNo": "Format-4", "categoryName": "GAM-Solar", "categoryValue": "GAMS", "classificationName": "Restricted", "classificationValue": "RESTRICTED", "issueNo": "345", "issueDate": "18 Aug 2023", "revisionNo": "678", "effectiveDate": "19 Aug 2027", "attachments": [{ "fileName": "29-MAY-2023_RAID Tracker (2) (1).xlsx", "url": "https://greenkotest.s3.ap-south-1.amazonaws.com/Formats/2023/08/26/29-MAY-2023_RAID%20Tracker%20%282%29%20%281%29.xlsx", "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "size": 27436, "cover": false }], "activeStatus": true, "createdAt": "26-Aug-2023 09:26:27", "updatedAt": "26-Aug-2023 09:28:17", "createdBy": "Girish M", "updatedBy": "Girish M" }]
  };
  activeFormats: any = [];
  submitted: boolean = false;
  @ViewChild('content') elementView: ElementRef;
  contentHeight: number;
  formatDocId: any;
  createForm: FormGroup;
  loading: boolean = false;
  histLoading: boolean = false;
  locationTypes: any = [];
  sbus: any = [];
  departments: any = [];
  allRoles: any = [];
  subKey: any;
  navData: any = [];
  validateAll: boolean = false;
  disableSubmitBtn: boolean = true;
  approveVisible: boolean = false;
  formatDetails: any = {};
  actions: any = [
    { name: 'Approve', key: 'APPROVE' },
    { name: 'Reject', key: 'REJECT' },
  ];
  minDate: any = new Date();
  parentPathName: any;
  historyFlag: boolean = false;
  urlSafe: SafeResourceUrl;
  classificationTypes: any = [];
  proCategories: any = [];
  subType: any;
  approvalsHistory: any = [];
  preHeader: any;
  visiblePdf: boolean = false;
  preImageUrl;
  allFormatList: any;

  constructor (private fb: FormBuilder,
    private route: ActivatedRoute,
    private gdmsService: GdmsService,
    private commonUtilityService: CommonUtilityService,
    private cd: ChangeDetectorRef,
    private router: Router,
    private httpClient: HttpClient,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private sanitizer: DomSanitizer, private renderer: Renderer2) {
    this.getMasterData('DM_CLASSIFICATION');
    this.getMasterData('DM_POLI_CATEGORY');
  }

  onResize(ev) {
    this.contentHeight = ev.contentRect.height + 67.75;
    // if (ev.contentRect.width < 500) {
    //   this.renderer.setStyle(ev.target, 'background', 'red');
    // } else {
    //   this.renderer.removeStyle(ev.target, 'background');
    // }
  }


  ngOnInit(): void {
    let subKeyList = [{ name: 'drafts', value: 'DRAFTS' }, { name: 'pendings', value: 'PENDING_WITH_ME' }, { name: 'reviews', value: 'PENDING_IN_REVIEW' }, { name: 'published', value: 'PUBLISHED' }];
    let parentPathList = [{ name: 'admin', value: 'ADMIN' }, { name: 'site', value: 'SITE' }];
    let currentPathList = this.router.url.split('/');
    this.allFormatList = currentPathList.includes('all');
    this.subKey = subKeyList.filter(value => currentPathList.includes(value.name))[0];
    let subTypesList = [{ name: 'policies', value: 'POLICIES' }, { name: 'procedures', value: 'PROCEDURES' }, { name: 'formats', value: 'FORMATS' }];
    this.subType = subTypesList.filter(value => currentPathList.includes(value.name))[0];
    this.parentPathName = parentPathList.filter(value => currentPathList.includes(value.name))[0];
    this.historyFlag = currentPathList.includes('history');
    this.formatDocId = this.route.snapshot.paramMap.get('id');
    if (this.formatDocId) {
      // this.getMasterData('LOCATION_TYPE');
      // this.getMasterData('SBU');
      // this.getMasterData('PROCEDURE_CATEGORY');
      // this.getMasterData('CLASSIFICATIONS_TYPE');
      // this.getMasterData('PM_KPI_CAPITAL');
      this.getCreateForm();
      setTimeout(() => {
        this.getFormatBydocId();
      }, 300);
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl('');
    }
  }

  getCreateForm() {
    this.createForm = this.fb.group({
      title: ['', Validators.required],
      classification: ['', Validators.required],
      category: ['', Validators.required],
      desc: ['', Validators.required],
      attachments: ['', Validators.required],
      action: [''],
      remarks: [''],
      reviewDate: [''],
      notes: ['', this.formatDetails && (this.formatDetails.originType === 'ISSUE' || this.formatDetails.originType === 'REVISION') ? Validators.required : []],
    });
  }

  get f() {
    return this.createForm.controls;
  }


  getProcessType() {
    if ((this.formatDetails.locCode && this.formatDetails.type === 'COMMON') || this.formatDetails.type === 'SPECIFIC') {
      return false;
    } else if (this.formatDetails.locCode === undefined && this.formatDetails.type === 'COMMON') {
      return true;
    }
  }

  getMasterData(key) {
    this.gdmsService.getMasterdata(key, {}).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        if (res.data.masterdata.key === 'LOCATION_TYPE') {
          this.locationTypes = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'SBU') {
          this.sbus = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DEPARTMENT') {
          this.departments = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'USER_ROLES') {
          this.allRoles = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DM_CLASSIFICATION') {
          this.classificationTypes = res.data.masterdata.options;
        } else if (res.data.masterdata.key === 'DM_POLI_CATEGORY') {
          this.proCategories = res.data.masterdata.options;
        }
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.cd.detectChanges();
    },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getFormatBydocId() {
    this.loading = true;
    this.gdmsService.getFormatDetailsBydocId(this.subKey, this.formatDocId, {}).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        this.formatDetails = res.data.format;
        this.createForm.patchValue({
          title: res.data.format.title,
          desc: res.data.format.desc,
          attachments: res.data.format.attachments ? res.data.format.attachments : [],
        });
        if (this.proCategories.length > 0) {
          this.createForm.patchValue({
            category: this.proCategories.filter(val => { return val.value === res.data.format.category; })[0]
          });
        }
        if (this.classificationTypes.length > 0) {
          this.createForm.patchValue({
            classification: this.classificationTypes.filter(val => { return val.value === res.data.format.classification; })[0]
          });
        }
        this.loading = false;
      } else {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err) => {
        this.loading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  fileUpload(event) {
    if (event.target.files[0].type === "application/pdf") {
      let file = event.target.files[0];
      let params = { key: file.name };
      this.loading = true;
      this.gdmsService.fileUpload({ params }).subscribe(res => {
        this.createForm.patchValue({
          attachments: [{
            url: res.body.Bucketpath,
            key: file.name,
            contentType: file.type,
            fileName: file.name,
            size: file.size,
          }]
        });
        this.loading = false;
        if (res.body && res.body.preSignedUrl !== '') {
          this.gdmsService.uploadUrl(res.body.preSignedUrl, file)
            .subscribe((res: any) => {
              this.createForm.patchValue({
                attachments: [{
                  url: res.body.Bucketpath,
                  key: file.name,
                  contentType: file.type,
                  fileName: file.name,
                  size: file.size,
                }]
              });
              this.loading = false;
              this.commonUtilityService.showSuccessMessage('File uploaded');
            }, (err) => {
              this.loading = false;
              // this.commonUtilityService.singleErrorMsg({
              //   error: { message: 'Upload failed' },
              // });
            });
        }
      });
    } else {
      this.loading = false;
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Upload PDF Only' },
      });
    }
  }

  formatBytes(bytes: any, decimals?: any) {
    if (bytes) {
      if (bytes === 0) {
        return '0 Bytes';
      }
      const k = 1024;
      const dm = decimals <= 0 ? 0 : decimals || 2;
      const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
  }


  // To filter formats in procedures tab
  filterFormat(event: any) {
    // this.loading = true;
    // this.intranetService
    //   .getFormats({
    //     params: {
    //       searchText: event.query ? event.query : '',
    //     },
    //     headers: { context: 'ADMIN_SEARCH_ACTIVE_STATUS_FORMATS' },
    //   })
    //   .subscribe(
    //     (res: any) => {
    //       this.loading = false;
    //       if (this.procedure.formats && this.procedure.formats.length > 0) {
    //         let result = res.formatList.filter(
    //           (obj1: any) =>
    //             !this.procedure.formats.some(
    //               (obj2: any) => obj2.docNo === obj1.docNo
    //             )
    //         );
    //         this.activeFormats = result;
    //       } else {
    //         this.activeFormats = res.formatList;
    //       }
    //       if(res['status'] === 'FAILURE'){
    //         this.commonService.showErrorMessage(res);
    //       }
    //     },
    //     (err: any) => {
    //       this.loading = false;
    //       this.commonService.showErrorMessage(err);
    //     }
    //   );
  }

  // To add new format to procedure
  addActiveFormat(format: any) {
    if (format) {
      if (!this.procedure.hasOwnProperty('formats')) {
        this.procedure.formats = [];
      }
      this.procedure.formats.push(format);
      this.procedure.selectedFormat = {};
    }
  }


  toggleForm(type: any) {
    if (type === 'add') {
      this.procedure = {};
      this.procedure.id = '';
      this.checked = false;
    } else if (type === 'cancel') {
      this.procedure = {};
      this.procedure.id = '';
      this.checked = false;
      // this.getProcedures({
      //   rows: this.procedureEvent ? this.procedureEvent.rows : 10,
      //   first: this.procedureEvent ? this.procedureEvent.first : 0,
      // });
    }
  }


  discardFormat() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Delete?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.createForm.patchValue({
          attachments: ''
        });
      },
      reject: (type) => {

      },
    });

  }

  discardProORFormat() {
    // if (this.createForm.value)
  }


  save() {
    let data = {
      docId: this.formatDetails.docId,
      title: this.createForm.value.title,
      desc: this.createForm.value.desc,
      classification: this.createForm.value.classification ? this.createForm.value.classification.value : '',
      category: this.createForm.value.category ? this.createForm.value.category.value : '',
      attachments: this.createForm.value.attachments ? this.createForm.value.attachments : [],
      notes: this.createForm.value.notes ? this.createForm.value.notes : ''
    };
    this.gdmsService.saveFormat({ data }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.commonUtilityService.showSuccessMessage(res.data.message);
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    },
      (err: any) => {
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  onSubmit() {
    if (this.createForm.invalid) {
      return;
    } else {
      this.confirmSubmit();
    }
  }


  confirmSubmit() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Submit?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        let data = {
          docId: this.formatDetails.docId,
          title: this.createForm.value.title,
          desc: this.createForm.value.desc,
          classification: this.createForm.value.classification ? this.createForm.value.classification.value : '',
          category: this.createForm.value.category ? this.createForm.value.category.value : '',
          attachments: this.createForm.value.attachments ? this.createForm.value.attachments : [],
          notes: this.createForm.value.notes ? this.createForm.value.notes : ''
        };
        this.loading = true;
        this.gdmsService.submitFormat({ data }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            this.formatDetails = Object.assign(this.formatDetails, res.data.format);
            this.getSidenav();
            this.getFormatApprovalHistory();
            this.router.navigateByUrl(`gdms/admin/formats/pendings/${res.data.format.docId}`);
            this.loading = false;
            window.scroll(0, 0);
            if (this.parentPathName.name === 'admin') {
              this.router.navigateByUrl(`gdms/admin/formats/pendings/${res.data.format.docId}`);
              return;
            }
            if (this.parentPathName.name === 'site') {
              this.router.navigateByUrl(`gdms/site/formats/pendings/${res.data.format.docId}`);
              return;
            }
          } else {
            this.commonUtilityService.showErrorMessage(res);
            this.loading = false;
          }
        },
          (err) => {
            this.commonUtilityService.showErrorMessage(err);
            this.loading = false;
          }
        );
      },
      reject: (type) => {

      },
    });
  }


  approveFormat() {
    this.approveVisible = true;
  }

  confirmApprove() {
    if (this.formatDetails.action === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required Action' },
      });
      return;
    } else if (this.formatDetails.remarks === '' || this.formatDetails.remarks === null || this.formatDetails.remarks === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required Remarks' },
      });
      return;
    } else {
      this.loading = true;
      let data = {
        docId: this.formatDetails.docId,
        action: this.formatDetails.action.key,
        remarks: this.formatDetails.remarks,
      };
      this.gdmsService.approveFormat({ data }).subscribe((res) => {
        if (res.status === 'SUCCESS') {
          this.getFormatBydocId();
          this.getSidenav();
          this.loading = false;
          window.scroll(0, 0);
          this.approveVisible = false;
          if (this.parentPathName.name === 'admin') {
            if (this.formatDetails.action.key === 'APPROVE') {
              this.router.navigateByUrl(`gdms/admin/formats/pendings/${this.formatDetails.docId}`);
              return;
            }
            if (this.formatDetails.action.key === 'REJECT') {
              this.router.navigateByUrl(`gdms/admin/formats/drafts/${this.formatDetails.docId}`);
              return;
            }
          }
          if (this.parentPathName.name === 'site') {
            if (this.formatDetails.action.key === 'APPROVE') {
              this.router.navigateByUrl(`gdms/site/formats/pendings/${this.formatDetails.docId}`);
              return;
            }
            if (this.formatDetails.action.key === 'REJECT') {
              this.router.navigateByUrl(`gdms/site/formats/drafts/${this.formatDetails.docId}`);
              return;
            }
          }
        } else {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      },
        (err) => {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }

  close() {
    this.approveVisible = false;
    this.formatDetails.action = "";
    this.formatDetails.remarks = "";
    this.formatDetails.reviewDate = "";
  }

  publish() {
    this.formatDetails.reviewDate = "";
    this.formatDetails.effectiveDate = "";
    this.formatDetails.issueDate = "";
    this.approveVisible = true;
  }

  confirmPublish() {
    if (this.formatDetails.reviewDate === '' || this.formatDetails.reviewDate === undefined || this.formatDetails.effectiveDate === '' || this.formatDetails.effectiveDate === undefined || this.formatDetails.issueDate === '' || this.formatDetails.issueDate === undefined) {
      this.commonUtilityService.singleErrorMsg({
        error: { message: 'Required All Fields' },
      });
      return;
    } else {
      this.loading = true;
      this.gdmsService.publishFormat({
        data: {
          docId: this.formatDetails.docId,
          reviewDate: moment(this.formatDetails.reviewDate).format('DD-MMM-YYYY'),
          effectiveDate: moment(this.formatDetails.effectiveDate).format('DD-MMM-YYYY'),
          issueDate: moment(this.formatDetails.issueDate).format('DD-MMM-YYYY')
        },

      }).subscribe((res) => {
        if (res.status === 'SUCCESS') {
          this.formatDetails = res.data.format;
          this.formatDetails = Object.assign(this.formatDetails, res.data.format);
          this.approveVisible = false;
          this.subKey = { name: 'published', value: 'PUBLISHED' };
          this.getSidenav();
          this.getFormatApprovalHistory();
          if (this.parentPathName.name === 'admin') {
            this.router.navigateByUrl(`/gdms/admin/formats/published/${res.data.format.docId}`);
            this.loading = false;
            return;
          }
          if (this.parentPathName.name === 'site') {
            this.router.navigateByUrl(`/gdms/site/formats/published/${res.data.format.docId}`);
            this.loading = false;
            return;
          }
          this.loading = false;
          window.scroll(0, 0);
        } else {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      },
        (err) => {
          this.loading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }


  discard() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to Discard?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.gdmsService.discardFormat({ params: { docId: this.formatDetails.docId } }).subscribe((res) => {
          if (res.status === 'SUCCESS') {
            this.getSidenav();
            if (this.parentPathName.name === 'admin') {
              this.router.navigateByUrl(`/gdms/admin/formats/${this.subKey.name}/list`);
              return;
            }
            if (this.parentPathName.name === 'site') {
              this.router.navigateByUrl(`/gdms/site/formats/${this.subKey.name}/list`);
            }
          } else {
            this.commonUtilityService.showErrorMessage(res);
          }
        },
          (err) => {
            this.commonUtilityService.showErrorMessage(err);
          }
        );
      },
      reject: (type) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            break;
          case ConfirmEventType.CANCEL:
            break;
        }
      },
    });
  }

  getFormatApprovalHistory() {
    this.histLoading = true;
    this.gdmsService.getFormatApprovalHistory(this.subKey, {
      params: { docId: this.formatDetails.docId },
    }).subscribe((res) => {
      if (res.status === 'SUCCESS') {
        this.approvalsHistory = res.data.hist;
        this.cd.detectChanges();
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.histLoading = false;
    },
      (err) => {
        this.histLoading = false;
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }

  getSidenav() {
    this.gdmsService.getDmSideNav({
    }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        if (this.parentPathName.name === 'admin') {
          res.data.nav.forEach(val => {
            if (val.value === 'ADMIN') {
              val.expanded = true;
            }
          });
        }
        if (this.parentPathName.name === 'site') {
          res.data.nav.forEach(val => {
            if (val.value === 'SITE') {
              val.expanded = true;
            }
          });
        }
        this.navData = res.data.nav;
        this.gdmsService.updateSideNav(this.navData);
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    }, (err) => {
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  parentCodeClick() {
    this.loading = true;
    let params: any = {
      code: this.formatDetails.code,
      version: this.formatDetails.commonVersion
    };
    this.gdmsService.getCommonParentDocId({ params }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        window.open(`/gdms/admin/published/${res.data.format.docId}`, "_blank");
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.loading = false;
    }, (err) => {
      this.loading = false;
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  goToBack() {
    if (this.allFormatList) {
      this.router.navigateByUrl(`/gdms/formats`);
      return;
    }
    if (this.parentPathName.name === 'admin') {
      this.router.navigateByUrl(`/gdms/admin/formats/${this.subKey.name}/list`);
      return;
    }
    if (this.parentPathName.name === 'site') {
      this.router.navigateByUrl(`/gdms/site/formats/${this.subKey.name}/list`);
    }

  }
  hidePreview() {
    this.preImageUrl = "";
  }

  preview(preUrl) {
    this.preHeader = preUrl.fileName;
    this.preImageUrl = preUrl.url;
    this.visiblePdf = true;
  }
  openDialog(dialog: Dialog) {
    dialog.maximized = true;
  }

}
