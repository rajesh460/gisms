import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DmFormatDetailsComponent } from './dm-format-details.component';

describe('DmFormatDetailsComponent', () => {
  let component: DmFormatDetailsComponent;
  let fixture: ComponentFixture<DmFormatDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DmFormatDetailsComponent]
    });
    fixture = TestBed.createComponent(DmFormatDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
