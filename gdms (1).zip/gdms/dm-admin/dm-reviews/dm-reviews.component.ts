import { ChangeDetectorRef, Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { GdmsService } from '../../gdms-services/gdms.service';
import { CommonUtilityService } from '../../../../services/common-utility.service'
import { Router } from '@angular/router';



@Component({
  selector: 'app-dm-reviews',
  templateUrl: './dm-reviews.component.html',
  styleUrls: ['./dm-reviews.component.scss']
})
export class DmReviewsComponent implements OnInit, OnChanges {

  @Input() details;
  @Input() approvalsHistory;
  customActivities: any;
  // approvalsHistory: any;

  detailsTab:boolean = true;
  commonTab:boolean = false;
  specificTab:boolean = false;
  notesTab:boolean = false;
  actDiv:boolean = false;
  showSpecificSearch:boolean = false;
  subKey: any;
  hasRun: boolean = false;
  loading: boolean = false;


  @ViewChild('content') elementView: ElementRef;
  contentHeight: number;
  constructor(private cd: ChangeDetectorRef, private gdmsService: GdmsService,
    private commonUtilityService: CommonUtilityService, private router: Router){


  }

  ngOnInit(): void {
    // this.getApprovalReviews();
  }

  ngOnChanges(changes: SimpleChanges): void {
      let subKeyList = [{ name: 'drafts', value: 'DRAFTS' }, { name: 'pendings', value: 'PENDING_WITH_ME' }, { name: 'reviews', value: 'PENDING_IN_REVIEW' }, { name: 'published', value: 'PUBLISHED' }];
      let currentPathList = this.router.url.split('/');
      this.subKey = subKeyList.filter(value => currentPathList.includes(value.name))[0];
      if (!this.hasRun) {
        // if (this.details && this.details.docId) {
        //   this.getApprovalReviews();
        // }
        this.hasRun = true;
      }
  }

  // getApprovalReviews() {
  //   this.loading = true;
  //   this.gdmsService.getProcedureApprovalHistory(this.subKey, {
  //     params: { docId: this.details.docId },
  //   }).subscribe((res) => {
  //     if (res.status === 'SUCCESS') {
  //       this.approvalsHistory = res.data.hist;
  //       this.hasRun = false;
  //       this.cd.detectChanges();
  //     } else {
  //       this.commonUtilityService.showErrorMessage(res);
  //     }
  //     this.loading = false;
  //   },
  //     (err) => {
  //       this.loading = false;
  //       this.commonUtilityService.showErrorMessage(err);
  //     }
  //   );
  // }

}
