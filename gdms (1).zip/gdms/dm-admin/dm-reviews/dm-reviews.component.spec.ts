import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DmReviewsComponent } from './dm-reviews.component';

describe('DmReviewsComponent', () => {
  let component: DmReviewsComponent;
  let fixture: ComponentFixture<DmReviewsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DmReviewsComponent]
    });
    fixture = TestBed.createComponent(DmReviewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
