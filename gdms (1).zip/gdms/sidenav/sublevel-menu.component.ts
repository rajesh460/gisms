import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { fadeInOut, INavbarData } from './helper';

@Component({
  selector: 'app-sublevel-menu',
  template: `

  <ul *ngIf="collapsed && data.items && data.items.length > 0"
    [@submenu]="expanded
      ? {value: 'visible',
          params: {transitionParams: '400ms cubic-bezier(0.86, 0, 0.07, 1)', height: '*'}}
      : {value: 'hidden',
          params: {transitionParams: '400ms cubic-bezier(0.86, 0, 0.07, 1)', height: '0'}}"
      class="sublevel-nav"
    >
    <ng-container *ngFor="let item of data.items;let si = index;">
        <ng-container *ngIf="(data?.routeLink==='admin' || data?.routeLink==='site') && data.items && data.items.length > 0 && si===0">
          {{data?.routeLink}} dd
        </ng-container>
      <li  class="sublevel-nav-item">
          <a class="sublevel-nav-link"
          (click)="handleClick(item)"
            *ngIf="item.items && item.items.length > 0"
            [ngClass]="getActiveClass(item)"
          >
            <i class="sublevel-link-icon fa fa-circle"></i>
            <span class="sublevel-link-text" @fadeInOut
                *ngIf="collapsed">{{item.label}}</span>
            <i  class="menu-collapse-icon"
              [ngClass]="!item.expanded ? 'fal fa-angle-right' : 'fal fa-angle-down'"
            ></i>
          </a>
          <a class="sublevel-nav-link"
            *ngIf="!item.items || (item.items && item.items.length === 0)"
            [routerLink]="[item.routeLink]"
            routerLinkActive="active-sublevel" (click)="sideMenuClick(data)"
            [routerLinkActiveOptions]="{exact: true}"
          >
            <!-- <i *ngIf="item.label==='Drafts'" class="sublevel-link-icon fal fa fa-list" style="font-size:18px;"></i>
            <i *ngIf="item.label==='Pendings'" class="sublevel-link-icon fal fa fa-list" style="font-size:18px;"></i>
            <i *ngIf="item.label==='In Review'" class="sublevel-link-icon fal fa fa-list" style="font-size:18px;"></i>
            <i *ngIf="item.label==='Published'" class="sublevel-link-icon fal fa fa-list" style="font-size:18px;"></i>
            <i *ngIf="item.label==='Metrics'" class="sublevel-link-icon fal fa fa-cogs" style="font-size:18px;"></i> -->
            <span class="sublevel-link-text" @fadeInOut
               *ngIf="collapsed">{{item.label}} <span *ngIf="item?.count === 0 || item?.count > 0 "><small>{{item?.count}}</small></span> </span>
          </a>
          <div *ngIf="item.items && item.items.length > 0">
            <app-sublevel-menu
              [data]="item"
              [collapsed]="collapsed"
              [multiple]="multiple"
              [expanded]="item.expanded"
            ></app-sublevel-menu>
          </div>
      </li>
    </ng-container>
    </ul>
  `,
  styleUrls: ['./sidenav.component.scss'],
  animations: [
    fadeInOut,
    trigger('submenu', [
      state('hidden', style({
        height: '0',
        overflow: 'hidden'
      })),
      state('visible', style({
        height: '*'
      })),
      transition('visible <=> hidden', [style({ overflow: 'hidden' }),
      animate('{{transitionParams}}')]),
      transition('void => *', animate(0))
    ])
  ]
})
export class SublevelMenuComponent implements OnInit {

  @Input() data: INavbarData = {
    routeLink: '',
    icon: '',
    label: '',
    items: []
  };
  @Input() collapsed = false;
  @Input() animating: boolean | undefined;
  @Input() expanded: boolean | undefined;
  @Input() multiple: boolean = false;
  @Output() sideNavClick: EventEmitter<any> = new EventEmitter();

  constructor (public router: Router) { }

  ngOnInit(): void {
  }

  handleClick(item: any): void {
    if (!this.multiple) {
      if (this.data.items && this.data.items.length > 0) {
        for (let modelItem of this.data.items) {
          if (item !== modelItem && modelItem.expanded) {
            modelItem.expanded = false;
          }
        }
      }
    }
    item.expanded = !item.expanded;
  }

  getActiveClass(item: INavbarData): string {
    return item.expanded && this.router.url.includes(item.routeLink)
      ? 'active-sublevel'
      : '';
  }


  sideMenuClick(data) {
    this.sideNavClick.emit(data);
  }

}
