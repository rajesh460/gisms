import { animate, keyframes, style, transition, trigger } from '@angular/animations';
import { Component, Output, EventEmitter, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { fadeInOut, INavbarData } from './helper';
// import { navbarData } from './nav-data';
import { GdmsService } from '../gdms-services/gdms.service';
import { CommonUtilityService } from 'src/app/services/common-utility.service';

interface SideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss'],
  animations: [
    fadeInOut,
    trigger('rotate', [
      transition(':enter', [
        animate('1000ms',
          keyframes([
            style({ transform: 'rotate(0deg)', offset: '0' }),
            style({ transform: 'rotate(2turn)', offset: '1' })
          ])
        )
      ])
    ])
  ]
})
export class SidenavComponent implements OnInit {
  navLoading: boolean = false;
  toggleFilterFlag: boolean = false;
  @Output() onToggleSideNav: EventEmitter<SideNavToggle> = new EventEmitter();
  @Output() collapse: EventEmitter<any> = new EventEmitter();
  @Output() screenSize: EventEmitter<any> = new EventEmitter();
  collapsed = true;
  screenWidth = 0;
  navData: INavbarData[] = [];
  multiple: boolean = false;
  isToggleClicked: boolean = false;
  subKey: any;
  subType: any;
  parentKey: any;
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.screenWidth = window.innerWidth;
    if (this.screenWidth <= 768) {
      this.collapsed = false;
      this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
    }
  }

  constructor (public router: Router, private gdmsService: GdmsService, private commonUtilityService: CommonUtilityService) {
    this.getSideNav();
    router.events.subscribe(() => {
      if (this.screenWidth <= 578) {
        this.collapsed = false;
        this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
      }
    });
  }

  toggleFilter() {
    this.toggleFilterFlag = !this.toggleFilterFlag;
  }

  ngOnInit(): void {
    let parentList = [{ name: 'site', value: 'SITE' }, { name: 'admin', value: 'ADMIN' }];
    let currentPathList = this.router.url.split('/');
    this.parentKey = parentList.filter(value => currentPathList.includes(value.name))[0];
    let subKeyList = [{ name: 'drafts', value: 'DRAFTS' }, { name: 'pendings', value: 'PENDING_WITH_ME' }, { name: 'reviews', value: 'PENDING_IN_REVIEW' }, { name: 'published', value: 'PUBLISHED' }];
    this.subKey = subKeyList.filter(value => currentPathList.includes(value.name))[0];
    let subTypesList = [{ name: 'policies', value: 'POLICIES' }, { name: 'procedures', value: 'PROCEDURES' }, { name: 'formats', value: 'FORMATS' }];
    this.subType = subTypesList.filter(value => currentPathList.includes(value.name))[0];
    this.screenWidth = window.innerWidth;
    this.toggleCollapse();
    // this.gdmsService.data$.subscribe((data) => {
    //   this.navData = data;

    // });
  }

  parentClick(d) {
  }


  getSideNav() {
    this.navLoading = true;
    this.gdmsService.getDmSideNav({
    }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        res.data.nav.forEach(val => {
          if ((val.value === (this.subType && this.subType.value)) && val.routeLink.toLowerCase() === (this.parentKey && this.parentKey.name.toLowerCase())) {
            val.expanded = true;
          }
        });
        this.navData = res.data.nav;
        //     const newItem = {
        //       "routeLink": "metrics/search",
        //       "icon": "fal fa-metrics",
        //       "label": "Custom Search",
        //       "value": "CUSTOM",
        //       "count": null
        //   };

        //   for (let i = 0; i < this.navData.length; i++) {
        //     if (this.navData[i].routeLink === "metrics") {
        //         // Check if the "items" property exists and is an array
        //         if (!this.navData[i].hasOwnProperty("items") || !Array.isArray(this.navData[i].items)) {
        //             this.navData[i].items = []; // If not, initialize it as an empty array
        //         }

        //         // Add the new item to the "Metrics" parent's "items" array
        //         this.navData[i].items.push(newItem);

        //         // Break out of the loop since we found and updated the "Metrics" parent
        //         break;
        //     }
        // }
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
      this.navLoading = false;
    }, (err) => {
      this.navLoading = false;
      this.commonUtilityService.showErrorMessage(err);
    });
  }

  toggleCollapse(): void {
    this.collapsed = !this.collapsed;
    if (this.collapsed) {
      this.isToggleClicked = true;
    } else {
      this.isToggleClicked = false;
    }
    this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
  }

  closeSidenav(): void {
    this.collapsed = false;
    this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
  }

  handleClick(item: INavbarData): void {
    this.shrinkItems(item);
    if (!item.expanded) {
      this.sideNavClick(item);
    }
    item.expanded = !item.expanded;
  }

  getActiveClass(data: INavbarData): string {
    return this.router.url.includes(data.label.toLowerCase()) && this.router.url.includes(data.routeLink.toLowerCase()) ? 'active' : '';
  }
  getActiveAll(data: INavbarData): string {
    return this.router.url.includes('all') && this.router.url.includes(data.routeLink.toLowerCase()) ? 'activeAll' : '';
  }
  shrinkItems(item: INavbarData): void {
    // if(item.routeLink==='admin' && item.items){
    //   this.router.navigate(['/gpms/admin/drafts/process-list']);
    // }else if(item.routeLink==='site' && item.items){
    //   this.router.navigate(['/gpms/site/drafts/process-list']);
    // }
    if (!this.multiple) {
      if (!this.collapsed) {
        this.collapsed = true;
        this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
      }
      for (let modelItem of this.navData) {
        if (item !== modelItem && modelItem.expanded) {
          modelItem.expanded = false;
        }
      }
    }
  }

  mouseEnter(name: string) {
    // if (!this.isToggleClicked) {
    //   this.collapsed = !this.collapsed;
    //   this.onToggleSideNav.emit({collapsed: this.collapsed, screenWidth: this.screenWidth});
    // }
  }

  mouseLeave(name: string) {
    // if (!this.isToggleClicked) {
    // this.collapsed = false;
    // this.onToggleSideNav.emit({collapsed: this.collapsed, screenWidth: this.screenWidth});
    // }
  }

  sideNavClick(item) {
    this.navLoading = true;
    this.gdmsService.getDmSideNav({
    }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        // this.navData = res.data.nav;
        const filteredItems = res.data.nav.filter(item => item.value !== undefined);
        filteredItems.filter((x) => x && x.value === item.value).map((x) => { return x.expanded = true; });
      } else {
        this.commonUtilityService.showErrorMessage(res);
        this.navLoading = false;
      }
      this.navLoading = false;
    }, (err) => {
      this.navLoading = false;
      this.commonUtilityService.showErrorMessage(err);
    });

  }

}
