import { INavbarData } from './helper';

export const navbarData: INavbarData[] = [
  {
    routeLink: 'dashboard',
    icon: 'fal fa-analytics',
    label: 'Dashboard',
  },
  {
      routeLink: 'admin',
      icon: 'fal fa-users',
      label: 'Admin',
      items: [
          {
              routeLink: 'drafts/process-list',
              icon:'fal fa-home',
              label: 'Drafts'
          },
          {
              routeLink: 'pendings/process-list',
              label: 'Pendings'
          },
      ]
  },
  {
    routeLink: 'site',
    icon: 'fal fa-list-alt',
    label: 'Site',
    items: [
        {
            routeLink: 'process-list',
            icon:'fal fa-home',
            label: 'Drafts'
        },
        {
            routeLink: 'process-list',
            label: 'Pendings'
        },
    ]
},
];


