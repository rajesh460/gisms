import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteFormatsListComponent } from './dm-site-formats-list.component';

describe('SiteFormatsListComponent', () => {
  let component: SiteFormatsListComponent;
  let fixture: ComponentFixture<SiteFormatsListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SiteFormatsListComponent]
    });
    fixture = TestBed.createComponent(SiteFormatsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
