import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SitePoliciesListComponent } from './dm-site-policies-list.component';

describe('SitePoliciesListComponent', () => {
  let component: SitePoliciesListComponent;
  let fixture: ComponentFixture<SitePoliciesListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SitePoliciesListComponent]
    });
    fixture = TestBed.createComponent(SitePoliciesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
