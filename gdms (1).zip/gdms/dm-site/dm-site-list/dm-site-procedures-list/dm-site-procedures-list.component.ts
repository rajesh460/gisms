import { Component, HostListener, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import {
  FormGroup,
  FormControl,
  Validators,
  FormArray,
  FormBuilder,
  AbstractControl,
} from '@angular/forms';
import { GdmsService } from '../../../gdms-services/gdms.service';
import { CommonUtilityService } from 'src/app/services/common-utility.service';
import { LazyLoadEvent, MenuItem } from 'primeng/api';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-site-procedures-list',
  templateUrl: './dm-site-procedures-list.component.html',
  styleUrls: ['./dm-site-procedures-list.component.scss'],
})
export class SiteProceduresListComponent implements OnInit {
  screenHeight: number;
  ddLoading: boolean = false;
  items: MenuItem[] | undefined;
  @ViewChild('pTable') pTable!: Table;
  loading: boolean = false;
  createLoading: boolean = false;
  searchInputs: any;
  tableScrollHeight: any = 'calc(100vh - 159px)';
  visible: boolean = false;
  createForm: any = FormGroup<any>;
  submitted: boolean = false;
  allProcesses: any = [];
  locationTypesOpt: any = [];
  sbusOpt: any = [];
  departmentsOpt: any = [];
  paginatorOptions: any = {};
  allRecords = 0;
  searchLoading: boolean;
  processEvent: any;
  searchObj: any = {};
  localKeys: any = {};
  subKey: any;
  sbusByRole: any = [];
  deptsByRole: any = [];
  createdDepartmentRole: any = [];
  capitalOpt: any = [];
  materialTopics: any = [];
  showFilters: boolean = false;
  processData: any;
  navData: any = [];
  rowData: any;
  locationOpt: any = [];
  specificOpt: any = [
    { name: "All", value: '' },
    { name: "Specific", value: 'SPECIFIC' },
    { name: "Common ", value: 'COMMON' }
  ];
  classificationTypes: any = [];
  proCategories: any = [];
  subKeyList: any;
  subTypesList: any;
  subType: any;
  @ViewChild('myDiv', { static: true }) myDiv: ElementRef;
  divHeight: number;

  ngAfterViewInit() {
    // if (this.showFilters) {
    //   this.tableScrollHeight = 'calc(100vh - 273px)';
    // } else {
    //   this.tableScrollHeight = 'calc(100vh - 159px)';

    // }
    this.onDivHeightChange();
    this.cd.detectChanges();
  }
  ngAfterContentChecked() {

    this.cd.detectChanges();

  }

  @HostListener('window:resize', ['$event'])
  onDivHeightChange(event?: Event) {
    this.screenHeight = window.innerHeight;
    let scrollNumber = !this.showFilters ? 139 : 254;
    this.tableScrollHeight = (this.screenHeight - scrollNumber) + 'px';
  }



  constructor (
    private router: Router,
    private formBuilder: FormBuilder,
    private gdmsService: GdmsService,
    private cd: ChangeDetectorRef,
    private commonUtilityService: CommonUtilityService
  ) {
    this.items = [
      {
        label: '<span class="menu-icon"><img src="assets/revision.png" /> Revision</span>',
        // icon: 'pi pi-refresh',
        escape: false,
        command: (data) => {
          this.createIssueOrRevsion("REVISION");
        }
      },
      {
        label: '<span class="menu-icon"><img src="assets/issue.png" /> Issue</span>',
        escape: false,
        // icon: 'pi pi-times',
        command: (data) => {
          this.createIssueOrRevsion("ISSUE");
        }
      }

    ];
    this.paginatorOptions = {
      totalRecords: 0,
      rowsPerPageOptions: [25, 50, 75, 100],
      rows: 25,
      first: 0,
    };
  }

  navigateProcess = true;
  toggleMenu() {
    this.navigateProcess = false;
  }

  selectRow(process) {
    this.rowData = process;
  }

  toggleFilters(pTable: Table) {
    if (this.showFilters) {
      this.resetTable(pTable);
    }
    this.showFilters = !this.showFilters;
    this.onDivHeightChange();
  }

  ngOnInit() {
    this.subKeyList = [{ name: 'drafts', value: 'DRAFTS' }, { name: 'pendings', value: 'PENDING_WITH_ME' }, { name: 'reviews', value: 'PENDING_IN_REVIEW' }, { name: 'published', value: 'PUBLISHED' }];
    let currentPathList = this.router.url.split('/');
    this.subKey = this.subKeyList.filter(value => currentPathList.includes(value.name))[0];
    this.subTypesList = [{ name: 'policies', value: 'POLICIES' }, { name: 'procedures', value: 'PROCEDURES' }, { name: 'formats', value: 'FORMATS' }];
    this.subType = this.subTypesList.filter(value => currentPathList.includes(value.name))[0];
    this.localStorageData();
    if (localStorage.getItem(`${this.subType.name}Siet${this.subKey.name}Data`)) {
      this.processData = JSON.parse(localStorage.getItem(`${this.subType.name}Siet${this.subKey.name}Data`) || '{}');
      const locFilter = Object.keys(this.processData).filter((key) => !['limit', 'offset', 'processType'].includes(key));
      locFilter.forEach((val) => this.searchObj[val] = this.processData[val] || '');
      this.searchObj.processType = this.processData.processType && this.processData.processType.name === 'All' ? '' : this.processData.processType;
      this.paginatorOptions.rows = this.processData.limit ? Number(this.processData.limit) : 25;
      const processEvent = {
        first: this.processData.offset ? Number(this.processData.offset) : 0,
        rows: this.processData.limit ? Number(this.processData.limit) : 25,
      };
      if (this.searchObj.locType) {
        this.getSBUsByType(this.searchObj.locType, '');
      }
      if (this.searchObj.sbu) {
        this.selectedSbu(this.searchObj.sbu, '');

      }


      this.getProceduresList(processEvent);
      this.showFilters = Object.values(this.searchObj).some(Boolean);
      localStorage.removeItem(`${this.subType.name}Siet${this.subKey.name}Data`);
    } else {
      this.searchObj = {};
      // this.getProcessList();
    }

    this.createForm = this.formBuilder.group({
      locationType: [''],
      sbu: [''],
      deptName: ['', [Validators.required]],
      location: ['', [Validators.required]]
    });

    this.getMasterData('LOCATION_TYPE');
    this.getMasterData('DM_CLASSIFICATION');
    this.getMasterData('DM_PROC_CATEGORY');
    this.getLocationsByRole();
    // this.getSBUsByRole();
    // this.getDeptsByRole();
  }

  localStorageData() {
    const removeList = this.subKeyList.filter((val) => val.value !== this.subKey.value);
    removeList.forEach(key => localStorage.removeItem(`${this.subType.name}Siet${key.name}Data`));
    const removeTypes = this.subTypesList.filter((val) => val.value !== this.subType.value);
    this.subKeyList.forEach((val) => {
      removeTypes.forEach((key) => {
        localStorage.removeItem(`${key.name}Siet${val.name}Data`);
      });

    });
    this.subKeyList.forEach((val) => {
      this.subTypesList.forEach((key) => {
        localStorage.removeItem(`${key.name}Admin${val.name}Data`);
      });

    });
    localStorage.removeItem('proceduresData');
    localStorage.removeItem('policiesData');
    localStorage.removeItem('formatsData');
  }

  getMasterData(key) {
    this.gdmsService.getMasterdata(key, {}).subscribe(
      (res) => {
        if (res && res.status === 'SUCCESS') {
          if (res.data.masterdata.key === 'LOCATION_TYPE') {
            this.locationTypesOpt = res.data.masterdata.options;
          } else if (res.data.masterdata.key === 'SBU') {
            this.sbusOpt = res.data.masterdata.options;
          } else if (res.data.masterdata.key === 'DM_CLASSIFICATION') {
            this.classificationTypes = res.data.masterdata.options.map((val) => {
              return { name: val.name, code: val.value, ...val };
            });
          }
          else if (res.data.masterdata.key === 'DM_PROC_CATEGORY') {
            this.proCategories = res.data.masterdata.options.map((val) => {
              return { name: val.name, code: val.value, ...val };
            });
          }
        }
        else {
          this.commonUtilityService.showErrorMessage(res);
        }
      },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
      }
    );
  }


  getSBUsByType(inputValue, valType) {
    if (valType === 'search') {
      this.searchObj.sbu = [];
      this.searchObj.deptCode = [];
      this.sbusByRole = [];
      this.createForm.value.sbu = [];
      this.deptsByRole = [];
      this.createForm.value.deptName = [];
    }
    const params = {
      type: inputValue ? (Array.isArray(inputValue) ? inputValue.map(x => x.value) : inputValue.value) : '',
    };
    this.searchLoading = true;
    this.gdmsService.getSubByType({ params }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        this.sbusByRole = res.data.options;
        this.searchLoading = false;
      } else {
        this.commonUtilityService.showErrorMessage(res);
        this.searchLoading = false;
      }
    }, (err) => {
      this.commonUtilityService.showErrorMessage(err);
      this.searchLoading = false;
    });
  }


  selectedSbu(inputValue, valType) {
    if (valType === 'search') {
      this.deptsByRole = [];
      this.searchObj.deptCode = [];

    }
    const params = {
      sbu: inputValue ? (Array.isArray(inputValue) ? inputValue.map(x => x.value) : inputValue.value) : '',
    };
    this.searchLoading = true;
    this.gdmsService.departmentsBySbu({ params }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        if (res.data && res.data.depts) {
          this.deptsByRole = res.data.depts.map((val) => {
            return { name: val.name, code: val.value, ...val };
          });
          this.searchLoading = false;

        } else {
          this.deptsByRole = [];
          this.searchLoading = false;
        }
      } else {
        this.searchLoading = false;
        this.commonUtilityService.showErrorMessage(res);
      }
    }, (err) => {
      this.commonUtilityService.showErrorMessage(err);
      this.searchLoading = false;
    });
  }



  createProcessDialog(pTable: Table) {
    if (Object.values(this.searchObj).some(Boolean)) {
      this.resetTable(pTable);
    }
    this.submitted = false;
    this.visible = true;
    this.createForm.get('locationType').reset();
    this.createForm.get('sbu').reset();
    this.createForm.get('deptName').reset();
    this.createForm.patchValue({
      deptName: ''
    });
    this.createdDepartmentRole = [];
    this.sbusByRole = [];

  }

  get f(): { [key: string]: AbstractControl; } {
    return this.createForm.controls;
  }

  createProcedure() {
    this.submitted = true;
    if (this.createForm.invalid) {
      return;
    } else {
      this.createLoading = true;
      let data: any = {};
      data.locType = this.createForm.value.location ? this.createForm.value.location.type : '';
      data.sbu = this.createForm.value.location ? this.createForm.value.location.sbu : '';
      data.deptCode = this.createForm.value.deptName.code;
      data.locCode = this.createForm.value.location.code;
      this.gdmsService.createProcedure({ data }).subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.commonUtilityService.showSuccessMessage(res.data.message);
          this.getSidenav();
          this.router.navigateByUrl(
            `gdms/site/procedures/drafts/${res.data.procedure.docId}`
          );
        } else {
          this.commonUtilityService.showErrorMessage(res);
        }
        this.createLoading = false;
      },
        (err) => {
          this.createLoading = false;
          this.commonUtilityService.showErrorMessage(err);
        }
      );
    }
  }

  close() {
    this.visible = false;
  }

  getLocationsByRole() {
    this.searchLoading = true;
    this.gdmsService.getLocationsByRole({
      params: {},
    }).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        this.locationOpt = res.data.locations;
        this.searchLoading = false;
      } else {
        this.commonUtilityService.showErrorMessage(res);
        this.searchLoading = false;
      }
    },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
        this.searchLoading = false;
      });
  }

  getDepartmentsByLocation(inputValue, valType) {
    if (valType === 'search') {
      this.departmentsOpt = [];
      this.searchObj.deptCode = [];
      this.createForm.value.deptName = [];
    }
    this.searchLoading = true;
    const params = {
      locCodes: inputValue ? (Array.isArray(inputValue) ? inputValue.map(x => x.code) : inputValue.code) : '',
    };
    this.gdmsService.getDepartmentsByLocation({ params }).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        if (res.data && res.data.depts) {
          this.departmentsOpt = res.data.depts;
          this.searchLoading = false;
          // this.searchObj.deptCode = []
        }
        else {
          this.departmentsOpt = [];
          this.searchLoading = false;
        }
        // this.processListByRoles = [];
        this.searchLoading = false;
        // this.selectedProcess = undefined;

      } else {
        this.commonUtilityService.showErrorMessage(res);
        this.searchLoading = false;
      }
    },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
        this.searchLoading = false;
      }
    );
  }


  changeDept() {
    this.createForm.patchValue({
      selectedProcessType: ''
    });
    this.submitted = false;
    // this.selectedProcess = undefined;
    // this.processListByRoles = [];
  }



  getProceduresList(event?: LazyLoadEvent) {
    if (event != undefined) {
      this.paginatorOptions.first = event ? event.first : 0;
    } else {
      this.paginatorOptions.first = 0;
    }
    this.searchLoading = true;
    const params = {
      locType: this.searchObj.locType && this.searchObj.locType.value ? this.searchObj.locType.value : '',
      classification: this.searchObj.classification ? this.searchObj.classification.map(x => x.value) : '',
      category: this.searchObj.category ? this.searchObj.category.map(x => x.code) : '',
      sbu: this.searchObj.sbu ? this.searchObj.sbu.map(x => x.value) : '',
      deptCode: this.searchObj.deptCode ? this.searchObj.deptCode.map(x => x.code) : '',
      searchText: this.searchObj.searchText ? this.searchObj.searchText : '',
      locCode: this.searchObj.locCode ? this.searchObj.locCode.map(x => x.code) : '',
      processType: this.searchObj.processType && this.searchObj.processType.value ? this.searchObj.processType.value : '',
      limit: event ? event.rows : this.paginatorOptions.rows,
      offset: event ? event.first : this.paginatorOptions.first,
      mainKey: 'SITE',
      subKey: this.subKey.value
    };

    this.gdmsService.getProcedures(this.subKey, { params, }).subscribe((res) => {
      if (res && res.status === 'SUCCESS') {
        this.allProcesses = res.data.procedures;
        this.paginatorOptions.totalRecords = res.data.totalRecords;
        this.localKeys.limit = params.limit ? params.limit : 25;
        this.localKeys.offset = params.offset ? params.offset : 0;
        const localObj = Object.keys(params).filter(key => !['limit', 'offset', 'mainKey', 'subKey'].includes(key));
        localObj.forEach((key) => {
          this.localKeys[key] = this.searchObj[key] || '';
        });
        this.pTable.scrollTo({ top: 0, behavior: 'smooth' });
        this.searchLoading = false;
      } else {
        this.commonUtilityService.showErrorMessage(res);
        this.searchLoading = false;
      }
    },
      (err) => {
        this.commonUtilityService.showErrorMessage(err);
        this.searchLoading = false;
      }
    );
    // this.cd.detectChanges();
  }


  updateTable(pTable: Table) {
    pTable.reset();
  }

  resetTable(pTable: Table) {
    localStorage.removeItem(`${this.subType.name}Siet${this.subKey.name}Data`);
    this.searchObj = {};
    this.deptsByRole = [];
    this.materialTopics = [];
    this.pTable.rows = 25;
    this.pTable.scrollTo({ top: 0, behavior: 'smooth' });
    this.updateTable(pTable);

  }

  createNavigate(docId) {
    if (this.navigateProcess) {
      const navigationExtras: NavigationExtras = {
        queryParams: {
          locType: this.localKeys.locType,
          sbu: this.localKeys.sbu,
          deptCode: this.localKeys.deptCode,
          limit: this.localKeys.limit,
          offset: this.localKeys.offset,
        },
      };
      this.router.navigateByUrl(`gdms/site/procedures/${this.subKey.name}/${docId}`, navigationExtras);
      localStorage.setItem(`${this.subType.name}Siet${this.subKey.name}Data`, JSON.stringify(this.localKeys));
    }
    this.navigateProcess = true;
  }

  createIssueOrRevsion(originType) {
    if (this.navigateProcess) {
      const navigationExtras: NavigationExtras = {
        queryParams: {
          locType: this.localKeys.locType,
          sbu: this.localKeys.sbu,
          deptCode: this.localKeys.deptCode,
          limit: this.localKeys.limit,
          offset: this.localKeys.offset,
        },
      };
      this.createLoading = true;
      let data: any = {
        procedureDocNo: this.rowData.proDocNo,
        originVersion: this.rowData.version,
        locCode: this.rowData.locCode ? this.rowData.locCode : "",
        originType: originType,
      };
      this.gdmsService.createIssueOrRevisionProcedure({ data }).subscribe(res => {
        if (res.status === 'SUCCESS') {
          this.getSidenav();
          this.createLoading = false;
          this.router.navigateByUrl(`gdms/site/procedures/drafts/${res.data.procedure.docId}`, navigationExtras);
        } else {
          this.createLoading = false;
          this.commonUtilityService.showErrorMessage(res);
        }
      }, (err) => {
        this.createLoading = false;
        this.commonUtilityService.showErrorMessage(err);
      });
      localStorage.setItem(`${this.subType.name}Siet${this.subKey.name}Data`, JSON.stringify(this.localKeys));
    }
    this.navigateProcess = true;
  }


  getSidenav() {
    this.gdmsService.getDmSideNav({
    }).subscribe(res => {
      if (res.status === 'SUCCESS') {
        this.navData = res.data.nav;
        this.gdmsService.updateSideNav(this.navData);
      } else {
        this.commonUtilityService.showErrorMessage(res);
      }
    }, (err) => {
      this.commonUtilityService.showErrorMessage(err);
    });
  }


}
