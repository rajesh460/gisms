import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteProceduresListComponent } from './dm-site-procedures-list.component';

describe('SiteProceduresListComponent', () => {
  let component: SiteProceduresListComponent;
  let fixture: ComponentFixture<SiteProceduresListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SiteProceduresListComponent]
    });
    fixture = TestBed.createComponent(SiteProceduresListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
