import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GdmsRoutingModule } from './gdms-routing.module';
import { GdmsBaseComponent } from './gdms-base/gdms-base.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';

import { SidenavComponent } from './sidenav/sidenav.component';
import { SublevelMenuComponent } from './sidenav/sublevel-menu.component';
import { GdmsApiService } from './gdms-services/gdms.api.service';
import { GdmsService } from './gdms-services/gdms.service';
import { PrimengModule } from '../../primeng-module/primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { Safe } from 'src/app/pipes/sanitize-pipe';

import { AdminPoliciesListComponent } from './dm-admin/dm-admin-list/dm-admin-policies-list/dm-admin-policies-list.component';
import { AdminProceduresListComponent } from './dm-admin/dm-admin-list/dm-admin-procedures-list/dm-admin-procedures-list.component';
import { AdminFormatsListComponent } from './dm-admin/dm-admin-list/dm-admin-formats-list/dm-admin-formats-list.component';
import { SitePoliciesListComponent } from './dm-site/dm-site-list/dm-site-policies-list/dm-site-policies-list.component';
import { SiteFormatsListComponent } from './dm-site/dm-site-list/dm-site-formats-list/dm-site-formats-list.component';
import { SiteProceduresListComponent } from './dm-site/dm-site-list/dm-site-procedures-list/dm-site-procedures-list.component';
import { ProceduresComponent } from './procedures/procedures.component';
import { FormatsComponent } from './formats/formats.component';
import { PoliciesComponent } from './policies/policies.component';

import { DmPolicyDetailsComponent } from './dm-admin/dm-admin-create/dm-policy-details/dm-policy-details.component';
import { DmProcedureDetailsComponent } from './dm-admin/dm-admin-create/dm-procedure-details/dm-procedure-details.component';
import { DmFormatDetailsComponent } from './dm-admin/dm-admin-create/dm-format-details/dm-format-details.component';

import { SharedModule } from '../../shared/shared.module'
import { DmReviewsComponent } from './dm-admin/dm-reviews/dm-reviews.component';
@NgModule({
  declarations: [
    GdmsBaseComponent,
    DashboardComponent,
    HeaderComponent,
    SidenavComponent,
    SublevelMenuComponent,
    AdminPoliciesListComponent,
    AdminProceduresListComponent,
    AdminFormatsListComponent,
    SitePoliciesListComponent,
    SiteProceduresListComponent,
    SiteFormatsListComponent,
    FormatsComponent,
    ProceduresComponent,
    PoliciesComponent,
    DmPolicyDetailsComponent,
    DmProcedureDetailsComponent,
    DmFormatDetailsComponent,
    DmReviewsComponent
  ],
  imports: [
    CommonModule,
    GdmsRoutingModule,
    PrimengModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  providers: [GdmsApiService, GdmsService],
})
export class GdmsModule { }
