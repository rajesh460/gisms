import { DOCUMENT } from '@angular/common';
import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { GlobalService } from 'src/app/services/global.service';

import { CommonUtilityService } from 'src/app/services/common-utility.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  user: any = {};

  settingsModel: any;
  workSpaces: any;
  visible: boolean;
  hideme = {};
  data: any = {};
  hasAdminRoleFlag: boolean = false;
  hasUserManagementRoleFlag: boolean = false;
  items: MenuItem[];
  userProfile: any;

  constructor(
    private global: GlobalService,
    private router: Router,
    // private commonServices: CommonService,
    private commonUtilityService: CommonUtilityService
  ) {
    const userRoles = this.global.getLocalItem('roles', true);
    this.hasUserManagementRoleFlag = this.hasUserManagementRole(userRoles, ['APP_ADMIN', 'SITE_HEAD', 'CLUSTER_HEAD']);
    this.hasAdminRoleFlag = this.hasAdminRole(userRoles, ['APP_ADMIN', 'IMS_REP', 'IMS_ADMIN']);
    // this.hasReveiwerRoleFlag = this.hasAdminRole(userRoles, ['REVIEWER']);
  }

  ngOnInit(): void {
    if (localStorage.getItem('userData')) {
      this.userProfile = JSON.parse(localStorage.getItem('userData') || '{}');
    }
    this.user = this.global.authentication;

    this.data = this.user;
    this.visible = false;
    this.settingsModel = false;
  }

  hasAdminRole(arr, list) {
    if (arr != null && arr.length > 0 && list != null && list.length > 0) {
      for (var i = 0; i < list.length; i++) {
        if (arr.indexOf(list[i]) > -1) {
          return true;
        }
      }
    }
    return false;
  }

  hasUserManagementRole(arr, list) {
    if (arr != null && arr.length > 0 && list != null && list.length > 0) {
      for (var i = 0; i < list.length; i++) {
        if (arr.indexOf(list[i]) > -1) {
          return true;
        }
      }
    }
    return false;
  }



  openSettingsModal() {
    this.visible = true;
    this.settingsModel = true;
  }

  @HostListener('window:unload', ['$event'])
  public unloadHandler($event) {
    // this.global.removeLocalItem('etdauth');
    // this.global.removeLocalItem('roles');
  }

  logout() {
    this.global.removeLocalItem('etdauth');
    this.global.removeLocalItem('roles');
     this.global.removeLocalItem('accessToken');
    this.router.navigate(['/login']);
    localStorage.clear();
  }

  gotoEtdAdmin(){
    this.router.navigate(['/admin/etd-admin']);
  }

  gotoDownload(){
    this.router.navigate(['/admin/etd-download']);
  }
  gotoUpload(){
    this.router.navigate(['/admin/etd-upload']);
  }

  gotoAdmin(){
    this.router.navigate(['/admin/manage']);
  }
  gotoHome() {
    this.router.navigate(['/admin/declarations']);
  }
  gotoUserMgmt() {
    this.router.navigate(['/admin/user-management']);
  }
  gotoEmailNotifications() {
    this.router.navigate(['/admin/email-notifications']);
  }
  gotoReports() {
    this.router.navigate(['/admin/reports']);
  }
  gotoManual() {
    this.router.navigate(['/admin/manual']);
  }

  settingsModelClose(ev) {
    this.visible = false;
    this.settingsModel = false;
  }



}
