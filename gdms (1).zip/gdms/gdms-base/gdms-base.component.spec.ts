import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GdmsBaseComponent } from './gdms-base.component';

describe('GdmsBaseComponent', () => {
  let component: GdmsBaseComponent;
  let fixture: ComponentFixture<GdmsBaseComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GdmsBaseComponent]
    });
    fixture = TestBed.createComponent(GdmsBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
