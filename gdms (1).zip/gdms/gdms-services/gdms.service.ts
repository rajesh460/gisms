import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { GdmsApiService } from './gdms.api.service';
import { HttpService } from '../../../services/http.service';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root',
})
export class GdmsService {
  empId: any;
  private dataSubject = new BehaviorSubject<any>([]);
  public data$ = this.dataSubject.asObservable();

  constructor (
    private http: HttpService,
    private gdmsApiService: GdmsApiService,
    private http1: HttpClient
  ) { }


  updateSideNav(nevData: string) {
    this.dataSubject.next(nevData);
  }

  getProfiles(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getProfiles');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getProfileByEmpId(empId: any, obj?: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getIntranetUrl('getProfileByEmpId').replace('{empId}', empId);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getLoginUserRoles(empId: any, obj?: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getLoginUserRoles').replace('{empId}', empId);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getUserProfiles(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getIntranetUrl('getUserProfiles');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getDmSideNav(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDmSideNav');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

    getMasterdata(docId: any, obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getMasterdata').replace('{docId}', docId);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getSubByType(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getSubByType');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
  
  departmentsBySbu(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('departmentsBySbu');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  // Policies
  createPolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createPolicy');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getPolicies(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedPolicies');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getPolicies');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  getPolicyDetailsBydocId(status: any, docId: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedPolicyDetailsBydocId').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getPolicyDetailsBydocId').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  savePolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('savePolicy');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  submitPolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('submitPolicy');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  approvePolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('approvePolicy');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  publishPolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('publishPolicy');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  discardPolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('discardPolicy');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  getPolicyApprovalHistory(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPolicyPublishedApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getPolicyApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  // Procedures
  createProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createProcedure');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

    getProcedures(status: any, obj: { params?: any; headers?: any; }) {
      if (status.value === 'PUBLISHED') {
        const url = this.gdmsApiService.getApiUrl('getPublishedProcedures');
        return this.http.xhr({ url, method: 'G', ...obj });
      } else {
        const url = this.gdmsApiService.getApiUrl('getProcedures');
        return this.http.xhr({ url, method: 'G', ...obj });
      }
  }

  getProcedureDetailsBydocId(status: any, docId: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedProcedureDetailsBydocId').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getProcedureDetailsBydocId').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  saveProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveProcedure');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  submitProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('submitProcedure');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  approveProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('approveProcedure');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  publishProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('publishProcedure');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  discardProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('discardProcedure');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  getProcedureApprovalHistory(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getProcedurePublishedApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getProcedureApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  // Formats
  createFormat(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createFormat');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

    getFormats(status: any, obj: { params?: any; headers?: any; }) {
      if (status.value === 'PUBLISHED') {
        const url = this.gdmsApiService.getApiUrl('getPublishedFormats');
        return this.http.xhr({ url, method: 'G', ...obj });
      } else {
        const url = this.gdmsApiService.getApiUrl('getFormats');
        return this.http.xhr({ url, method: 'G', ...obj });
      }
  }

  getLinkedFormats(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedLinkedFormats');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getLinkedFormats');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
}

  getFormatDetailsBydocId(status: any, docId: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedFormatDetailsBydocId').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getFormatDetailsBydocId').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  saveFormat(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveFormat');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  submitFormat(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('submitFormat');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  approveFormat(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('approveFormat');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  publishFormat(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('publishFormat');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  discardFormat(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('discardFormat');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  getFormatApprovalHistory(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getFormatPublishedApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getFormatApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }




  fileUpload(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('fileUpload');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  uploadUrl(url: any, file: any) {
    return this.http1.put<any>(url, file);
  }


  createIssueOrRevisionPolicy(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createIssueOrRevisionPolicy');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  createIssueOrRevisionProcedure(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createIssueOrRevisionProcedure');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getDepartmentsByLocation(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDepartmentsByLocation');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getLocationsByRole(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getLocationsByRole');
    return this.http.xhr({ url, method: 'G', ...obj });
  }






  



  




  getProcess(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getProcess');
    return this.http.xhr({ url, method: 'G', ...obj });
  }


  saveProcessIndicator(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveProcessIndicator');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getProcessIndicator(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getProcessIndicator');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
  saveUserManagement(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveUserManagement');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  deleteUserManagement(docId: any, obj?: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('deleteUserManagement').replace('{docId}', docId);
    return this.http.xhr({ url, method: 'D', ...obj });
  }
  //  deleteUserManagement(obj?: { params?: any; headers?: any; data?: any }) {
  //   const url = this.gdmsApiService.getApiUrl('deleteUserManagement');
  //   return this.http.xhr({ url, method: 'D', ...obj });
  // }

  userManagementRoles(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('userManagementRoles');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  userRoleSearch(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('userRoleSearch');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getPublishedProcess(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getPublishedProcess');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  searchMatrix(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('searchMatrix');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getSBUsByRole(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getSBUsByRole');
    return this.http.xhr({ url, method: 'G', ...obj });
  }


  getMaterialTopic(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getMaterialTopic');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getMaterialTopicByCapital(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getMaterialTopicByCapital');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
  getAllMaterialsTopics(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllMaterialsTopics');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
  getDepartmentTopicBysbu(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDepartmentTopicBysbu');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
  getAllDepartmentsSbu(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllDepartmentsSbu');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
  saveDepartmentTopic(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveDepartmentTopic');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  saveMaterialTopic(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveMaterialTopic');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  addMaterialTopic(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('addMaterialTopic');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  addDepartmentTopics(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('addDepartmentTopics');
    return this.http.xhr({ url, method: 'P', ...obj });
  }
  createProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createProcess');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  // createIssueOrRevision(obj: { params?: any; headers?: any; data?: any; }) {
  //   const url = this.gdmsApiService.getApiUrl('createIssueOrRevision');
  //   return this.http.xhr({ url, method: 'P', ...obj });
  // }

  getDeptsByRole(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDeptsByRole');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  adoptProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('adoptProcess');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  // getLocationsByRole(obj: { params?: any; headers?: any; }) {
  //   const url = this.gdmsApiService.getApiUrl('getLocationsByRole');
  //   return this.http.xhr({ url, method: 'G', ...obj });
  // }

  getLocationEmpId(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getLocationEmpId');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  // getDepartmentsByLocation(obj: { params?: any; headers?: any; }) {
  //   const url = this.gdmsApiService.getApiUrl('getDepartmentsByLocation');
  //   return this.http.xhr({ url, method: 'G', ...obj });
  // }

  saveProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveProcess');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getProcessBydocId(status: any, docId: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedProcessbyCode').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getProcessbyCode').replace('{docId}', docId);
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  getProcessbyCode(docId: any, obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getProcessbyCode').replace('{docId}', docId);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getPublishedProcessbyCode(docId: any, obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getPublishedProcessbyCode').replace('{docId}', docId);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getAllCommonActivites(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getAllPublishedActivities');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getAllActivities');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  getAllActivities(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllActivities');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getAllPublishedActivities(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllPublishedActivities');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getCommonActivities(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllActivities');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getCommonPublishedActivities(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllPublishedActivities');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getActivity(status: any, obj: { params?: any; headers?: any; }) {
    if (status === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedActivitiyByCode');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getActivitiyByCode');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  getActivitiyByCode(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getActivitiyByCode');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getPublishedActivitiyByCode(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getPublishedActivitiyByCode');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getSpecificActivities(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllActivities');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getSpecificPublishedActivities(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllPublishedActivities');
    return this.http.xhr({ url, method: 'G', ...obj });
  }


  createActivity(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createActivity');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  deleteActivity(obj?: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('deleteActivity');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  createIndicator(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('createIndicator');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getAllPmKpis(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllPmKpis');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getCommonIndicatorsByActivity(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedIndicatorsByActivity');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getIndicatorsByActivity');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  getIndicatorsByActivity(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getIndicatorsByActivity');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getPublishedIndicatorsByActivity(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getPublishedIndicatorsByActivity');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  deleteIndicator(obj?: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('deleteIndicator');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  // fileUpload(obj: { params?: any; headers?: any; }) {
  //   const url = this.gdmsApiService.getApiUrl('fileUpload');
  //   return this.http.xhr({ url, method: 'G', ...obj });
  // }

  // uploadUrl(url: any, file: any) {
  //   return this.http1.put<any>(url, file);
  // }

  downloadFile(key: any, obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('downloadFile').replace('{key}', key);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  dragActivity(obj?: { data: any; params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('dragActivity');
    return this.http.xhr({ url, method: 'P', ...obj });
  }
  dragIndicator(obj?: { data: any; params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('dragIndicator');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getApprovals(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getApprovals');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  saveApproval(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('saveApproval');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getApprovalReviews(status: any, obj: { params?: any; headers?: any; }) {
    if (status.value === 'PUBLISHED') {
      const url = this.gdmsApiService.getApiUrl('getPublishedApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    } else {
      const url = this.gdmsApiService.getApiUrl('getApprovalHistory');
      return this.http.xhr({ url, method: 'G', ...obj });
    }
  }

  getApprovalHistory(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getApprovalHistory');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getPublishedApprovalHistory(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getPublishedApprovalHistory');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  deleteApproval(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('deleteApproval');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  discardProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('discardProcess');
    return this.http.xhr({ url, method: 'D', ...obj });
  }

  submitProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('submitProcess');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  approveProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('approveProcess');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  publishProcess(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('publishProcess');
    return this.http.xhr({ url, method: 'P', ...obj });
  }


  getMetrics(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getMetrics');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getAllMetrics(docId: any, obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getAllMetrics').replace('{docId}', docId);
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getSnapShotValues(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getSnapShotValues');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getIndicatorLocations(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getIndicatorLocations');
    return this.http.xhr({ url, method: 'G', ...obj });
  }


  getIndicatorsandMetricsByLocations(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getIndicatorsandMetricsByLocations');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getMetricsByLocaton(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getMetricsByLocaton');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  submitMetric(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('submitMetric');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getPendingMetrics(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getPendingMetrics');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getCommonParentDocId(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getCommonParentDocId');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getVersions(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getVersions');
    return this.http.xhr({ url, method: 'G', ...obj });
  }

  getDownloadExcel(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDownloadExcel');
    return this.http.xhr({ url, method: 'DW', ...obj });
  }
  getDownloadExcelMetrics(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDownloadExcelMetrics');
    return this.http.xhr({ url, method: 'DW', ...obj });
  }
  getDownloadExcelKpi(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getDownloadExcelKpi');
    return this.http.xhr({ url, method: 'DW', ...obj });
  }

  approveMetrics(obj: { params?: any; headers?: any; data?: any; }) {
    const url = this.gdmsApiService.getApiUrl('approveMetrics');
    return this.http.xhr({ url, method: 'P', ...obj });
  }

  getMetricBydocId(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getMetricBydocId');
    return this.http.xhr({ url, method: 'G', ...obj });
  }


  getSbusByTypeMulti(obj: { params?: any; headers?: any; }) {
    const url = this.gdmsApiService.getApiUrl('getSbusByTypeMulti');
    return this.http.xhr({ url, method: 'G', ...obj });
  }
}
