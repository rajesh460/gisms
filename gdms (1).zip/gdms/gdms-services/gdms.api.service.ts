import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable()
export class GdmsApiService {
  baseUrl = environment.baseUrl;
  intranetUrl = environment.intranetUrl;

  apiUrl: any = {
    getDmSideNav: '/api/dm/dashboard/nav',
    getMasterdata: '/api/masterdata/{docId}',
    getSubByType: '/api/loc/type/sbu',
    departmentsBySbu: '/api/dept/search',
    // policies
    createPolicy: '/api/dm/draft/policy/save',
    getPolicies: '/api/dm/draft/policies',
    getPublishedPolicies: '/api/dm/policies',
    getPolicyDetailsBydocId: '/api/dm/draft/policy/{docId}',
    getPublishedPolicyDetailsBydocId: '/api/dm/policy/{docId}',
    savePolicy: '/api/dm/draft/policy/update',
    submitPolicy: '/api/dm/draft/policy/submit',
    approvePolicy: '/api/dm/draft/policy/approve',
    publishPolicy: '/api/dm/draft/policy/publish',
    discardPolicy: '/api/dm/draft/policy',
    getPolicyApprovalHistory: '/api/dm/draft/policy/approval/hist',
    getPolicyPublishedApprovalHistory: '/api/dm/policy/approval/hist',
    // Procedures
    createProcedure: '/api/dm/draft/procedure/save',
    getProcedures: '/api/dm/draft/procedures',
    getPublishedProcedures: '/api/dm/procedures',
    getProcedureDetailsBydocId: '/api/dm/draft/procedure/{docId}',
    getPublishedProcedureDetailsBydocId: '/api/dm/procedure/{docId}',
    saveProcedure: '/api/dm/draft/procedure/update',
    submitProcedure: '/api/dm/draft/procedure/submit',
    approveProcedure: '/api/dm/draft/procedure/approve',
    publishProcedure: '/api/dm/draft/procedure/publish',
    discardProcedure: '/api/dm/draft/procedure',
    getProcedureApprovalHistory: '/api/dm/draft/procedure/approval/hist',
    getProcedurePublishedApprovalHistory: '/api/dm/procedure/approval/hist',
    // Formats
    createFormat: '/api/dm/draft/format/save',
    getFormats: '/api/dm/draft/formats',
    getPublishedFormats: '/api/dm/formats',
    getLinkedFormats: '/api/dm/draft/formats',
    getPublishedLinkedFormats: '/api/dm/format/ref',
    getFormatDetailsBydocId: '/api/dm/draft/format/{docId}',
    getPublishedFormatDetailsBydocId: '/api/dm/format/{docId}',
    saveFormat: '/api/dm/draft/format/update',
    submitFormat: '/api/dm/draft/format/submit',
    approveFormat: '/api/dm/draft/format/approve',
    publishFormat: '/api/dm/draft/format/publish',
    discardFormat: '/api/dm/draft/format',
    getFormatHist: '/api/pm/draft/format/approval/hist',
    getFormatApprovalHistory: '/api/dm/draft/format/approval/hist',
    getFormatPublishedApprovalHistory: '/api/dm/format/approval/hist',

    fileUpload: '/api/uploadFile',
    //  createIssueOrRevisionFormat: '/api/dm/format/version',
    createIssueOrRevisionPolicy: '/api/dm/policy/version',
    createIssueOrRevisionProcedure: '/api/dm/procedure/version',
    // getDepartmentsByLocation: '/api/location/depts',
    getDepartmentsByLocation: '/api/dept/search',
    getLocationsByRole: '/api/locations/options',


    // getPublishedProcess: '/api/pm/process',  // changed
    // getSBUsByRole: '/api/authorization/sbus',
    // getDeptsByRole: '/api/authorization/depts',
    // adoptProcess: '/api/pm/process/adopt',
    // discardProcess: '/api/pm/draft/process', // changed
    // getAllActivities: '/api/pm/draft/process/activities', // changed
    // getAllPublishedActivities: '/api/pm/process/activities',
    // getActivitiyByCode: '/api/pm/draft/process/actvity', // changed
    // getPublishedActivitiyByCode: '/api/pm/process/actvity',
    // createActivity: '/api/pm/draft/process/actvity', // changed
    // deleteActivity: '/api/pm/draft/process/activity', // changed
    // createIndicator: '/api/pm/draft/process/activity/indicator', // changed
    // getAllPmKpis: '/api/pm/kpis',
    // getIndicatorsByActivity: '/api/pm/draft/process/activity/indicators', // changed
    // getPublishedIndicatorsByActivity: '/api/pm/process/activity/indicators',
    // deleteIndicator: '/api/pm/draft/process/activity/indicator', // changed
    // getLoginUserRoles: '/api/authorization/roles/{empId}',
    // getProfileByEmpId: '/api/profiles/empId/{empId}',
    // downloadFile: '/api/downloadFile/{key}',
    // getApprovals: '/api/pm/process/approvals',
    // saveApproval: '/api/pm/process/approval',
    // getApprovalHistory: '/api/pm/draft/process/approval/hist', // changed
    // getPublishedApprovalHistory: '/api/pm/process/approval/hist',
    // deleteApproval: '/api/pm/process/approval',
    // submitProcess: '/api/pm/draft/process/submit', // changed
    // approveProcess: '/api/pm/draft/process/approve', // changed
    // publishProcess: '/api/pm/draft/process/published', // changed
    // dragActivity: '/api/pm/draft/process/actvity/seq', // changed
    // dragIndicator: '/api/pm/draft/process/actvity/indicator/seq', // changed
    // userRoleSearch: '/api/authorizations',
    // getLocationEmpId: '/api/locations',
    // getUserProfiles: '/api/profiles',
    // saveUserManagement: '/api/authorization',
    // deleteUserManagement: '/api/authorization/{docId}',
    // userManagementRoles: '/api/authorization/roles',
    // getMetrics: '/api/pm/process/metrics/indicator',
    // getAllMetrics: '/api/pm/process/metrics/{key}',
    // submitMetric: '/api/pm/process/metrics/submit',
    // getPendingMetrics: '/api/pm/process/metrics/pending',
    // searchMatrix: '/api/pm/process/metrics/data',
    // getMaterialTopic: '/api/pm/materialtopic',
    // saveMaterialTopic: '/api/pm/material/mapping',
    // addMaterialTopic: '/api/pm/materialtopic/name',
    // getMaterialTopicByCapital: '/api/pm/materialtopics/capitals',
    // saveDepartmentTopic: '/api/depts/sbu/mapping',
    // getDepartmentTopicBysbu: '/api/depts',
    // addDepartmentTopics: '/api/dept/save',
    // getAllDepartmentsSbu: '/api/depts/sbu',
    // getAllMaterialsTopics: '/api/pm/materialtopics/capital',
    // saveProcessIndicator: '/api/pm/kpis',
    // getProcessIndicator: '/api/pm/kpis/search',
    // createIssueOrRevision: '/api/pm/process/version',
    // getCommonParentDocId: '/api/pm/process/version',
    // getVersions: '/api/pm/process/published/versions',
    // getDownloadExcel: '/api/pm/process/export',
    // getDownloadExcelMetrics: '/api/pm/process/metrics/export',
    // getIndicatorLocations: '/api/pm/process/metrics/locs',
    // getIndicatorsandMetricsByLocations: '/api/pm/process/locs/metrics',
    // getMetricsByLocaton: '/api/pm/process/metrics',
    // approveMetrics: '/api/pm/process/metrics/approve',
    // getMetricBydocId: '/api/pm/metrics/loc/kpi/docId',
    // getSbusByTypeMulti: '/api/locations/type',
    // getDownloadExcelKpi: '/api/pm/kpis/export',
    // getSnapShotValues: '/api/pm/process/metrics/snapshot'
  };

  constructor () { }

  getApiUrl(key?: any) {
    return this.baseUrl + this.apiUrl[key];
  }

  getIntranetUrl(key?: any) {
    return this.intranetUrl + this.apiUrl[key];
  }
}
